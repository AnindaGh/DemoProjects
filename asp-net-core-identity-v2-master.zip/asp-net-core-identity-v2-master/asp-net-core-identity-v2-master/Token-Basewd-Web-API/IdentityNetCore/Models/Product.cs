﻿namespace IdentityNetCore.Models
{
    public class Product
    {
        public string Name { get; set; }
        public int Price { get; set; }
    }
}