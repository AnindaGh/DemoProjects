﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCRCommonLib.JsonStruct.LogEntry
{
    /// <summary>
    /// JSON struct to send data to log webservice
    /// </summary>
    public class LogEntryInputStruct
    {
        /// <summary>
        /// Name of the log to write to
        /// </summary>
        public String LogName { get; set; }

        /// <summary>
        /// Loglevel: INFO, WARN, ERROR, DEBUG
        /// </summary>
        public String LogLevel { get; set; }

        /// <summary>
        /// Message to write to logfile
        /// </summary>
        public String LogMessage { get; set; }

        /// <summary>
        /// Default constructor
        /// </summary>
        public LogEntryInputStruct()
        {
        }
    }
}