﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OCRCommonLib.DataAccess;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text; 

namespace OCRCommonLib
{
    public class Recognition : IRecognition
    {
        protected static Utility utility;

        /// <summary>
        /// Compare list of OCR and CMS values and return list of results
        /// </summary>
        /// <param name="lstOcrCms"></param>
        /// <param name="marketName"></param>
        /// <param name="contractNumber"></param>
        /// <param name="connectionString"></param>
        /// <param name="logFileLocation"></param>
        /// <param name="logApplicationName"></param>
        /// <returns></returns>
        public List<OCR_CMS> CompareOcrAndCmsValues(List<OCR_CMS> lstOcrCms, string marketName, string contractNumber, string connectionString, string logFileLocation, string logApplicationName)
        {
            utility = new Utility(logFileLocation, logApplicationName);

            try
            {
                DBAccess dBAccess = new DBAccess(connectionString, logApplicationName, logFileLocation, marketName);

                string cmsJSON = dBAccess.GetCMSByContractNumber(marketName, contractNumber);

                //Convert JSON string to JSON object
                JObject data = JObject.Parse(cmsJSON);

                List<DocumentFieldStruct> docFieldList = dBAccess.GetDocFieldStructList(marketName);

                //Get fields with sub type that will be matched using common comparison method
                List<DocumentFieldStruct> filteredDocFieldList = (from list in docFieldList
                                where list.FieldSubType != ""
                                select list).ToList();

                foreach(OCR_CMS oc in lstOcrCms)
                {
                    //Retrieve field name from string of OCR field
                    List<string> strFieldSplit = oc.CmsFieldName.Split('_').ToList();
                    string fieldToMatch = strFieldSplit[1];

                    DocumentFieldStruct field = (from cmsField in filteredDocFieldList
                                                 where cmsField.FieldName == fieldToMatch
                                                 select cmsField).FirstOrDefault();

                    if(data[field.CmsNode][field.CmsElement].ToString() != "")
                    {
                        oc.CmsFieldValue = data[field.CmsNode][field.CmsElement].ToString();
                    }

                    oc.OcrCheckBoxFieldValue = IsMatched(oc.OcrCheckBoxFieldName, oc.OcrFieldValue, oc.CmsFieldValue, field.FieldType, field.FieldSubType);
                }
            }
            catch (Exception ex)
            {
                utility.WriteMessage(string.Format("[OCRCommonLib] CompareOcrAndCmsValues method error encountered {0}", ex.ToString()));
            }

            return lstOcrCms;
        }

        /// <summary>
        /// Match values based on data type and data sub type
        /// </summary>
        /// <param name="ocrCheckBoxFieldName"></param>
        /// <param name="ocrFieldValue"></param>
        /// <param name="cmsFieldValue"></param>
        /// <param name="dataType"></param>
        /// <param name="strSubtype"></param>
        /// <returns></returns>
        public int IsMatched(string ocrCheckBoxFieldName, string ocrFieldValue, string cmsFieldValue, string dataType, String strSubtype)
        {
            if (!string.IsNullOrEmpty(ocrCheckBoxFieldName))
            {
                switch (dataType)
                {
                    case "string":
                        if (!string.IsNullOrEmpty(cmsFieldValue))
                        {
                            int iMatchResult = 0;
                            String strOcrField, strCmsField;
                            if (String.Compare(strSubtype, "removespace", true) == 0)
                            {
                                strOcrField = ocrFieldValue.Replace(" ", "");
                                strOcrField = strOcrField.Replace("\r", ""); strOcrField = strOcrField.Replace("\n", "");
                                strCmsField = cmsFieldValue.Replace(" ", "");
                                strCmsField = strCmsField.Replace("\r", ""); strCmsField = strCmsField.Replace("\n", "");
                                iMatchResult = strOcrField.ToLower().Trim().Equals(strCmsField.ToLower().Trim()) ? 1 : 0;
                            }
                            else if (String.Compare(strSubtype, "currency", true) == 0)
                            {
                                strOcrField = ocrFieldValue.Replace(" ", "");
                                strOcrField = ocrFieldValue.Trim();
                                strOcrField = ChangeCurrencyField(strOcrField);
                                double dOcrVal, dCmsVal;
                                Boolean isOcrValid = Double.TryParse(strOcrField, out dOcrVal);
                                Boolean isCmsValid = Double.TryParse(cmsFieldValue, out dCmsVal);
                                if (isOcrValid && isCmsValid)
                                {
                                    iMatchResult = Math.Round(dOcrVal, 2) == Math.Round(dCmsVal, 2) ? 1 : 0;
                                }
                                else
                                {
                                    iMatchResult = strOcrField.Trim().Equals(cmsFieldValue.Trim()) ? 1 : 0;
                                }
                            }
                            else if (String.Compare(strSubtype, "date", true) == 0)
                            {
                                iMatchResult = 0;
                                DateTime objOcrDate, objCmsDate;
                                CultureInfo culture = CultureInfo.CreateSpecificCulture("en-AU");
                                DateTimeStyles styles = DateTimeStyles.None;
                                Boolean isOcrValid = DateTime.TryParse(ocrFieldValue, culture, styles, out objOcrDate);
                                Boolean isCmsValid = DateTime.TryParse(cmsFieldValue, culture, styles, out objCmsDate);
                                if (isOcrValid && isCmsValid)
                                {
                                    iMatchResult = DateTime.Compare(objOcrDate, objCmsDate) == 0 ? 1 : 0;
                                }
                            }
                            else
                            {
                                iMatchResult = ocrFieldValue.ToLower().Trim().Equals(cmsFieldValue.ToLower().Trim()) ? 1 : 0;
                            }
                            return iMatchResult;
                        }
                        break;
                    case "int":
                        if (!string.IsNullOrEmpty(cmsFieldValue))
                        {
                            try
                            {
                                return (Convert.ToInt32(ocrFieldValue) == Convert.ToInt32(cmsFieldValue)) ? 1 : 0;
                            }
                            catch
                            {
                                return 0;
                            }
                        }
                        break;
                    case "decimal":
                        if (!string.IsNullOrEmpty(cmsFieldValue))
                        {
                            try
                            {
                                return (Convert.ToDecimal(ocrFieldValue.ToString()) == Convert.ToDecimal(cmsFieldValue.ToString())) ? 1 : 0;
                            }
                            catch
                            {
                                return 0;
                            }
                        }
                        break;
                }
            }
            return 0;
        }

        /// <summary>
        /// Autocorrect currency field value
        /// </summary>
        /// <param name="strFieldVal"></param>
        /// <returns></returns>
        public String ChangeCurrencyField(String strFieldVal)
        {
            String strEnd = "";
            StringBuilder objBuf = new StringBuilder();
            if (strFieldVal.Length >= 3)
            {
                int iStartIdx = strFieldVal.Length - 3;
                strEnd = strFieldVal.Substring(iStartIdx, 3);
                strEnd = strEnd.Replace(" ", ".");
                objBuf.Append(strFieldVal.Substring(0, iStartIdx));
                objBuf = objBuf.Replace(" ", "");
                objBuf = objBuf.Replace(",", "");
                objBuf = objBuf.Replace(".", "");
                objBuf.Append(strEnd);
            }
            else
            {
                objBuf.Append(strFieldVal);
            }
            return objBuf.ToString();
        }
    }
}
