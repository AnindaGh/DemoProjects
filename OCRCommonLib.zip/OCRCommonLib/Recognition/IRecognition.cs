﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCRCommonLib
{
    public interface IRecognition
    {
        List<OCR_CMS> CompareOcrAndCmsValues(List<OCR_CMS> lstOcrCms, string marketName, string contractNumber, string connectionString, string logFileLocation, string logApplicationName);

        int IsMatched(string ocrCheckBoxFieldName, string ocrFieldValue, string cmsFieldValue, string dataType, String strSubtype);

    }
}
