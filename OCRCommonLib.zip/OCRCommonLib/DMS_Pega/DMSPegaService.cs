﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using OCRCommonLib.RegionalDMS;

namespace OCRCommonLib.DMS_Pega
{
    public class DMSPegaService
    {
        public AuthResponse Authenticate(string endpoint, string username, string password)
        {
            // decrypt password
            password = EncryptionLib.Encryption.Decrypt(password);

            CWS4PegaClient _client = GetPegaClient(endpoint);
            AuthResponse authResponse = _client.Authenticate(username, password);
            return authResponse;
        }

        public UploadResponse UploadFile(string endpoint, string token, FileUploadRequest fileUploadRequest)
        {
            CWS4PegaClient _client = GetPegaClient(endpoint);
            UploadResponse uploadResponse = _client.UploadDocument(
                fileUploadRequest.CategoryId, 
                fileUploadRequest.ContractNumber, 
                fileUploadRequest.ApplicationNumber, 
                fileUploadRequest.DocumentType, 
                fileUploadRequest.CustomerName, 
                fileUploadRequest.Area, 
                fileUploadRequest.DocumentPath, 
                fileUploadRequest.FileName, 
                fileUploadRequest.File, 
                token);


            return uploadResponse;

        }

        /// <summary>
        /// This method will create the FileUploadRequest object
        /// </summary> 
        /// <param name="applicationNumber">Application Number</param>
        /// <param name="contractNumber">Contract Number</param>
        /// <param name="areaType">Area type is always eContracting</param>
        /// <param name="financeType">Loan or Lease</param>
        /// <param name="documentType">Document Type is always Contract</param>
        /// <param name="filePath">Full path</param>
        /// <param name="documentPath">Livelink document path</param>
        /// <param name="categoryID">JP_Retail category ID =639874</param>
        /// <returns></returns>
        public FileUploadRequest CreateFileUploadRequest(
            string applicationNumber, 
            string contractNumber, 
            string areaType,
            string financeType,
            string documentType,
            string filePath,
            string documentPath,
            string categoryID,
            string applicationNamePrefix,
            string insuranceContactNumber)
        {
            FileUploadRequest fileUploadRequest = new FileUploadRequest();

            try
            {
                // check FILE first
                if (File.Exists(filePath))
                {
                    fileUploadRequest.CategoryId = categoryID;
                    fileUploadRequest.ContractNumber = contractNumber;
                    fileUploadRequest.ApplicationNumber = applicationNumber;
                    fileUploadRequest.DocumentType = documentType;
                    fileUploadRequest.CustomerName = financeType;
                    fileUploadRequest.Area = areaType;
                    fileUploadRequest.DocumentPath = documentPath;
                    //fileUploadRequest.FileName = Path.GetFileName(filePath);
                    fileUploadRequest.FileName = applicationNamePrefix + insuranceContactNumber;
                    fileUploadRequest.File = File.ReadAllBytes(filePath); 
                } 
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return fileUploadRequest;
        }

        private CWS4PegaClient GetPegaClient(string endpoint)
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback =
                ((sender, certificate, chain, sslPolicyErrors) => true);

            var address = new EndpointAddress(endpoint);
            var useHttps = address.Uri.Scheme == Uri.UriSchemeHttps;
            CustomBinding result = new CustomBinding();
            TextMessageEncodingBindingElement textBindingElement = new TextMessageEncodingBindingElement();
            textBindingElement.MessageVersion = MessageVersion.CreateVersion(EnvelopeVersion.Soap12, AddressingVersion.None);
            result.Elements.Add(textBindingElement);
            var httpBindingElement = useHttps ? new HttpsTransportBindingElement() : new HttpTransportBindingElement();
            httpBindingElement.AllowCookies = true;
            httpBindingElement.MaxBufferSize = int.MaxValue;
            httpBindingElement.MaxReceivedMessageSize = int.MaxValue;
            result.Elements.Add(httpBindingElement);
            CWS4PegaClient _client = new CWS4PegaClient(result, address);
             
            return _client;
        }
    }
}
