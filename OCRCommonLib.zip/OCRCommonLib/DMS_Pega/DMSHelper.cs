﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCRCommonLib.DMS_Pega
{
    public class DMSHelper
    {
        // utility object
        protected static Utility utility;

        // declare global variables
        protected string _dbConnectionString;
        protected string _encryptedDBConnectionString;
        protected string _countryCode;
        protected string _logApplicationName;
        protected string _logAPI; 


        /// <summary>
        /// DMSHelper constructor 
        /// </summary>
        /// <param name="logApplicationName">log application name</param>
        /// <param name="logAPI">log API webservice</param> 
        public DMSHelper(string connectionString, string logApplicationName, string logAPI, string countryCode)
        {
            // assign vars
            _encryptedDBConnectionString = connectionString;
            _dbConnectionString = EncryptionLib.Encryption.Decrypt(connectionString);
            _countryCode = countryCode;
            _logApplicationName = logApplicationName;
            _logAPI = logAPI;

            // instantiate
            utility = new Utility(logAPI, logApplicationName);  
        }

        /// <summary>
        /// This method is for ABBYY Projects. It will call the DMSPegaService methods for file uploading
        /// </summary>
        /// <param name="DMSEndpoint">DMS Pega webservice endpoint</param>
        /// <param name="DMSUsername">DMS Username</param>
        /// <param name="DMSPassword">Encrypted DMS password</param>
        /// <param name="batchId">ABBYY Batch Id. Used as unique identifier</param>
        /// <param name="applicationNumber">Application Number</param>
        /// <param name="contractNumber">Contract Number</param>
        /// <param name="areaType">Area type is always eContracting</param>
        /// <param name="financeType">Loan or Lease</param>
        /// <param name="documentType">Document Type is always Contract</param>
        /// <param name="filePath">Full path</param>
        /// <param name="documentPath">Livelink document path</param>
        /// <param name="categoryID">JP_Retail category ID =639874</param>
        public void CallDMS(string DMSEndpoint, string DMSUsername, string DMSPassword, 
            int batchId, 
            string applicationNumber, 
            string contractNumber, 
            string areaType, 
            string financeType, 
            string documentType,  
            string filePath, 
            string documentPath, 
            string categoryID,
            string applicationNamePrefix,
            string insuranceContactNumber)
        { 
            try
            { 
                // instantiate DMSPegaService class
                DMSPegaService dmsPega = new DMSPegaService();
                utility.WriteMessage(String.Format("[DMSHelper]V10 Attempting to authenticate on endpoint [{0}] using credentials username=[{1}]", 
                    DMSEndpoint, DMSUsername));

                // generate token
                var authResponse = dmsPega.Authenticate(DMSEndpoint, DMSUsername, DMSPassword);

                // auth SUCCESS
                if (authResponse.success)
                {
                    utility.WriteMessage("[DMSHelper] Authentication success"); 

                    string token = authResponse.token;
                    // create FileUploadRequest object
                    FileUploadRequest fileUploadRequest = dmsPega.CreateFileUploadRequest(applicationNumber, contractNumber, areaType, financeType, documentType, filePath, documentPath, categoryID, applicationNamePrefix, insuranceContactNumber); 
                    utility.WriteMessage("[DMSHelper] Attempting to upload file...");

                    utility.WriteMessage(String.Format("categoryID :  {0}", fileUploadRequest.CategoryId ));
                    utility.WriteMessage(String.Format("contractNo :  {0}", fileUploadRequest.ContractNumber));
                    utility.WriteMessage(String.Format("applicationNo :  {0}", fileUploadRequest.ApplicationNumber));
                    utility.WriteMessage(String.Format("documentType :  {0}", fileUploadRequest.DocumentType));
                    utility.WriteMessage(String.Format("customerName :  {0}", fileUploadRequest.CustomerName));
                    utility.WriteMessage(String.Format("area :  {0}", fileUploadRequest.Area));
                    utility.WriteMessage(String.Format("csFilePath :  {0}", fileUploadRequest.DocumentPath));
                    utility.WriteMessage(String.Format("docName :  {0}", fileUploadRequest.FileName));

                    // upload File to DMS
                    var uploadResponse = dmsPega.UploadFile(DMSEndpoint, token, fileUploadRequest);
                    utility.WriteMessage(String.Format("[DMSHelper] UploadResponse Success=[{0}], ErrorCode=[{1}], ErrorString=[{1}], " +
                        uploadResponse.success, uploadResponse.errorCode, uploadResponse.errorString));
                    
                    // record upload response in DB
                    InsertLiveLinkTransaction(
                        batchId, 
                        applicationNumber, 
                        contractNumber, 
                        documentType, 
                        financeType, 
                        areaType,
                        filePath, 
                        uploadResponse.success.ToString(), 
                        uploadResponse.errorString);
                }
                // auth FAILED
                else
                {
                    utility.WriteMessage(String.Format("[DMSHelper] Authentication failed for DMS Username {0}", DMSUsername));
                }

            }
            catch (Exception ex)
            { 
                utility.WriteMessage(String.Format("[DMSHelper] CallDMS method error encountered {0}", ex.ToString()));
            }
        }  

        /// <summary>
        /// This method will insert into [OCRLiveLinkTransaction]
        /// It will record whether upload was successful or not
        /// </summary>
        /// <param name="batchId">ABBYY Batch ID</param>
        /// <param name="applicationNumber">Unique identifier</param> 
        /// <param name="contractNumber">Unique identifier</param>
        /// <param name="documentType">DMS Pega DocumentType</param>
        /// <param name="keyPhrase">DMS Pega Finance Type</param>
        /// <param name="teamName">DMS Pega  Area Type</param>
        /// <param name="filePath">Full path</param>
        /// <param name="status">DMS upload status</param>
        /// <param name="errorMessage">DMS error message</param> 
        private void InsertLiveLinkTransaction(
            int batchId,
            string applicationNumber, 
            string contractNumber, 
            string documentType, 
            string keyPhrase, 
            string teamName, 
            string filePath,
            string status,
            string errorMessage)
        {
            try
            {
                DataAccess.DBAccess db = new DataAccess.DBAccess(_encryptedDBConnectionString, _logApplicationName, _logAPI, _countryCode);

                bool result = db.InsertLiveLinkTransaction(batchId, _countryCode, applicationNumber,
                    contractNumber, documentType, keyPhrase, teamName,
                    Path.GetFileName(filePath), filePath, status, errorMessage);
                utility.WriteMessage(String.Format("[DMSHelper] InsertLiveLinkTransaction returned status=[{0}]", result.ToString()));

            }
            catch (Exception ex)
            {
                utility.WriteMessage(String.Format("[DMSHelper] InsertLiveLinkTransaction method error encountered {0}", ex.ToString()));
            }

        }
    }
}
