﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCRCommonLib.DMS_Pega
{
    /// <summary>
    /// Request model to upload file to DMS
    /// </summary>
    public class FileUploadRequest : ICloneable
    {
        /// <summary>
        /// Application Number for creating folder to store docs
        /// </summary>
        public string ApplicationNumber { get; set; }
        /// <summary>
        /// Contract Number for creating folder to store docs
        /// </summary>
        public string ContractNumber { get; set; }
        /// <summary>
        /// Finance Type ex. Loan/Lease
        /// </summary>
        public string CustomerName { get; set; }
        /// <summary>
        /// Document path in DMS where doc to be stored
        /// </summary>
        public string DocumentPath { get; set; }
        /// <summary>
        /// Area = "eContracting"
        /// </summary>
        public string Area { get; set; }
        /// <summary>
        /// ID/Contract in DMS
        /// </summary>
        public string DocumentType { get; set; }
        /// <summary>
        /// CategoryId from DocMan
        /// </summary>
        public string CategoryId { get; set; }
        /// <summary>
        /// Market Code
        /// </summary>
        public string MarketCode { get; set; }
        /// <summary>
        /// Client_Name from Country Settings in Infinite JP Admin
        /// </summary>
        public string ClientName { get; set; }
        /// <summary>
        /// Client_Secret from Country Settings in Infinite JP Admin
        /// </summary>
        public string ClientSecret { get; set; }
        /// <summary>
        /// FileName to be saved
        /// </summary>
        public string FileName { get; set; }
        /// <summary>
        /// File Contents
        /// </summary>
        public byte[] File { get; set; }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
