﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Json;
using OCRCommonLib.JsonStruct.LogEntry;
using System.IO;

namespace OCRCommonLib
{
    /// <summary>
    /// Contains utility functions to log messages 
    /// </summary>
    public class Utility : IUtility
    {
        protected string _API;
        protected string _appLogName;
        /// <summary>
        /// Constructor to pass applicatonLogName and Logging service URL
        /// </summary>
        /// <param name="webServiceURL">logging service API URL</param>
        /// <param name="applicationLogName">application log name</param>
        public Utility(string webServiceURL, string applicationLogName)
        {
            _API = webServiceURL;
            _appLogName = applicationLogName;
        }

        /// <summary>
        /// Write backend log messages.
        /// </summary>
        /// <param name="message">the message to log</param>
        /// <param name="logServiceUrl">URL of the logging webservice, passed in from ABBYY</param>
        /// <returns></returns>
        public String WriteMessage(string message)
        {
            //Trust all certificates
            System.Net.ServicePointManager.ServerCertificateValidationCallback =
                ((sender, certificate, chain, sslPolicyErrors) => true);

            var request = (HttpWebRequest)WebRequest.Create(_API);

            // LogName must point to correct folder
            LogEntryInputStruct objInput = new LogEntryInputStruct();
            objInput.LogName = _appLogName;
            objInput.LogLevel = "INFO";
            objInput.LogMessage = message;

            DataContractJsonSerializer js = new DataContractJsonSerializer(typeof(LogEntryInputStruct));
            MemoryStream ms = new MemoryStream();
            js.WriteObject(ms, objInput);
            ms.Position = 0;
            StreamReader sr = new StreamReader(ms);
            String strPostData = sr.ReadToEnd();
            sr.Close();
            ms.Close();
            var data = Encoding.ASCII.GetBytes(strPostData);

            request.Method = "POST";
            request.ContentType = "application/json";
            request.ContentLength = data.Length;

            using (var stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }
            var response = (HttpWebResponse)request.GetResponse();
            HttpStatusCode objStatusCode = response.StatusCode;
            String strResponse = "";
            if (response.StatusCode == HttpStatusCode.OK)
            {
                strResponse = new StreamReader(response.GetResponseStream()).ReadToEnd();
                if (!String.IsNullOrEmpty(strResponse))
                {
                    //ApplicationStatusResponse objApplicationStatus = ApplicationStatusResponseFromJson(strResponse);
                }
            }
            return strResponse;
        }
        
        /// <summary>
        /// Authenticate username if it exists in ABBYY DB
        /// </summary>
        /// <param name="Username"></param>
        /// <returns></returns>
        public string AuthenticateUser(string Username)
        {
            //Trust all certificates
            System.Net.ServicePointManager.ServerCertificateValidationCallback =
                ((sender, certificate, chain, sslPolicyErrors) => true);

            var request = (HttpWebRequest)WebRequest.Create(_API);

            DataContractJsonSerializer js = new DataContractJsonSerializer(typeof(string));
            MemoryStream ms = new MemoryStream();
            js.WriteObject(ms, Username);
            ms.Position = 0;
            StreamReader sr = new StreamReader(ms);
            String strPostData = sr.ReadToEnd();
            sr.Close();
            ms.Close();
            var data = Encoding.ASCII.GetBytes(strPostData);

            request.Method = "POST";
            request.ContentType = "application/json";
            request.ContentLength = data.Length;

            using (var stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }
            var response = (HttpWebResponse)request.GetResponse();
            HttpStatusCode objStatusCode = response.StatusCode;
            String strResponse = "";
            if (response.StatusCode == HttpStatusCode.OK)
            {
                strResponse = new StreamReader(response.GetResponseStream()).ReadToEnd();
            }
            return strResponse;
        }
    }
}
