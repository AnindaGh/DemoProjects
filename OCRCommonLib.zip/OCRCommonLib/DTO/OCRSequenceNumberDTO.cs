﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCRCommonLib.DTO
{
    public class OCRSequenceNumberDTO
    {
        /// <summary>
        /// MarketName
        /// </summary>
        public String MarketName { get; set; }

        /// <summary>
        /// SequenceGroupName 
        /// Eg: Project name , Document Name or any kind of grouping
        /// </summary>
        public String SequenceGroupName { get; set; }

        /// <summary>
        /// Pre Text for the Sequence Number 
        /// Eg: if FinalSequenceNumber is this 201027_0001 ==> PreText = "201027" , Separator = "_" , Number = 0001 (need to format to string LatestSequenceNumber based on DecimalFormatSpecifier )
        /// PreText can be null/empty if not needed
        /// </summary>
        public String PreText { get; set; }

        /// <summary>
        /// Separator : Which separates PreText and LatestSequenceNumber
        /// Separator can be null/empty if no PreText
        /// </summary>
        public String Separator { get; set; }

        /// <summary>
        /// Latest SequenceNumber
        /// </summary>
        public int LatestSequenceNumber { get; set; }

        /// <summary>
        /// IncrementBy : How to increment by 
        /// </summary>
        public int IncrementBy { get; set; }

        /// <summary>
        /// DecimalFormatSpecifier : How need to Format LatestSequenceNumber to string 
        /// Eg: D4 --> 1 to "0001" , 22 to "0022"
        /// Default D means just convert same --> 1 to "1"
        /// </summary>
        public String DecimalFormatSpecifier { get; set; }

        /// <summary>
        /// CreatedDate
        /// </summary>
        public DateTime CreatedDate { get; set; }

        /// <summary>
        /// UpdatedDate
        /// </summary>
        public DateTime? UpdatedDate { get; set; }

        /// <summary>
        /// IsLock : true means SequenceNumber is Processing , false means can use number.
        /// </summary>
        public bool IsLock { get; set; }
    }
}
