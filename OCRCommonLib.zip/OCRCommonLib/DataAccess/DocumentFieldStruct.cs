﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCRCommonLib.DataAccess
{
    public class DocumentFieldStruct
    {

        public long DocumentID { get; set; }
        public String DocumentName { get; set; }
        public String FieldName { get; set; }
        public String CmsNode { get; set; }
        public String CmsElement { get; set; }
        public String FieldType { get; set; }
        public String FieldSubType { get; set; }


        public DocumentFieldStruct()
        {
            //
        }

        public DocumentFieldStruct(long strDocID, String strDocName, String strFieldName, String strCmsNode, String strCmsElement, String strFieldType, String strFieldSubType)
        {
            DocumentID = strDocID;
            DocumentName = strDocName;
            FieldName = strFieldName;
            CmsNode = strCmsNode;
            CmsElement = strCmsElement;
            FieldType = strFieldType;
            FieldSubType = strFieldSubType;
        }

    }
}
