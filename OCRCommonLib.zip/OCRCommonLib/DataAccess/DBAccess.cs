﻿using Newtonsoft.Json;
using OCRCommonLib.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 

namespace OCRCommonLib.DataAccess
{
    /// <summary>
    /// Contains methods to connect to ABBYY database
    /// </summary>
    public class DBAccess : IDBAccess
    {
        // instantiate utility object
        protected static Utility utility;

        // declare global variables
        protected string _dbConnectionString;
        protected string _countryCode;

        /// <summary>
        /// DBAccess constructor 
        /// </summary>
        /// <param name="logApplicationName">log application name</param>
        /// <param name="logAPI">log API webservice</param>
        /// <param name="connectionString">encrypted connection string</param>
        /// <param name="countryCode">two letter country code to denote market</param>
        public DBAccess(string connectionString, string logApplicationName, string logAPI, string countryCode)
        {
            utility = new Utility(logAPI, logApplicationName);
            _dbConnectionString = EncryptionLib.Encryption.Decrypt(connectionString); 
            _countryCode = countryCode;
        }

        /// <summary>
        /// Retrieve the list of document definition names with compiled order
        /// </summary>
        /// <returns></returns>
        public List<string> RetrieveCompileOrder()
        {
            List<string> objCompileOrder = new List<string>();
            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                String strDD;
                String strSql = "SELECT DISTINCT * FROM OCRDocumentMaster WHERE MarketName = @countrycode AND DocumentDefinition IS NOT NULL Order by CompileOrder ASC";
                conn.Open();
                SqlCommand cmd = new SqlCommand(strSql, conn);
                var objCountryCodeParam = new SqlParameter("countrycode", SqlDbType.VarChar, 20);
                objCountryCodeParam.Value = _countryCode;
                cmd.Parameters.Add(objCountryCodeParam);
                SqlDataReader objReader = cmd.ExecuteReader();
                while (objReader.Read())
                {
                    strDD = objReader["DocumentDefinition"].ToString();
                    objCompileOrder.Add(strDD);
                }
                objReader.Close();
            }
            return objCompileOrder;
        }

        /// <summary>
        /// Get list of fieldNames from table [OCRDocumentFieldMaster]
        /// </summary>
        /// <param name="strCountryCode">market country code</param>
        /// <returns>list of string for all the fields found in a document</returns>
        public List<string> GetFieldList(string strCountryCode)
        {
            // return list variable
            List<string> lstFieldNames = new List<string>();

            try
            {

                using (SqlConnection conn = new SqlConnection(_dbConnectionString))
                {
                    String strFieldName = "";
                    String strSql = @"SELECT [FieldName] FROM [OCRDocumentFieldMaster] 
                                    WHERE MarketName = @countrycode AND [status] = 'A'";
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    var objCountryCodeParam = new SqlParameter("countrycode", SqlDbType.VarChar, 20);
                    objCountryCodeParam.Value = strCountryCode;
                    cmd.Parameters.Add(objCountryCodeParam);
                    SqlDataReader objReader = cmd.ExecuteReader();
                    while (objReader.Read())
                    {
                        strFieldName = objReader["FieldName"].ToString();

                        lstFieldNames.Add(strFieldName);
                    }
                    objReader.Close();
                }
            }
            catch (Exception ex)
            {
                utility.WriteMessage(String.Format("[OCRCommonLib] GetFieldList method error encountered {0}", ex.ToString()));
            }

            return lstFieldNames;
        }

        /// <summary>
        /// Get list of document names, field names from table [OCRDocumentFieldMaster]
        /// Get corresponding JSON mapping from table [OCRCMSMapping]
        /// </summary>
        /// <param name="strCountryCode">market country code</param>
        /// <returns>list of string for all the fields found in a document</returns>
        public List<DocumentFieldStruct> GetDocFieldStructList(String strCountryCode)
        {
            // return list variable
            List<DocumentFieldStruct> lstFieldStruct = new List<DocumentFieldStruct>();

            try
            {
                DocumentFieldStruct objFieldStruct;
                using (SqlConnection conn = new SqlConnection(_dbConnectionString))
                {
                    String strFieldName, strDocName, strCmsNode, strCmsElement, strFieldType, strFieldSubType;
                    long iDocID;
                    String strSql = @"select t1.*, ISNULL(t2.CmsNode,'') as CMSLevel1, ISNULL(t2.CmsField,'') AS CmsLevel2
                                    from OCRDocumentFieldMaster t1
	                                    left join OCRCmsMapping t2 on t1.DocumentName = t2.DocumentType and t1.FieldName = t2.OcrField
                                    where t1.MarketName= @countrycode and t1.Status='A'";
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    var objCountryCodeParam = new SqlParameter("countrycode", SqlDbType.VarChar, 20);
                    objCountryCodeParam.Value = strCountryCode;
                    cmd.Parameters.Add(objCountryCodeParam);
                    SqlDataReader objReader = cmd.ExecuteReader();
                    while (objReader.Read())
                    {
                        iDocID = 0;
                        if (objReader["DocumentId"] != DBNull.Value)
                        {
                            iDocID = Convert.ToInt64(objReader["DocumentId"]);
                        }
                        strDocName = objReader["DocumentName"].ToString();
                        strFieldName = objReader["FieldName"].ToString();
                        strCmsNode = objReader["CMSLevel1"].ToString();
                        strCmsElement = objReader["CMSLevel2"].ToString();
                        strFieldType = objReader["FieldType"].ToString();
                        strFieldSubType = objReader["FieldSubType"].ToString();


                        objFieldStruct = new DocumentFieldStruct(iDocID, strDocName, strFieldName, strCmsNode, strCmsElement, strFieldType, strFieldSubType);
                        lstFieldStruct.Add(objFieldStruct);
                    }
                    objReader.Close();
                }
            }
            catch (Exception ex)
            {
                utility.WriteMessage(String.Format("[OCRCommonLib] GetDocFieldStructList method error encountered {0}", ex.ToString()));
            }

            return lstFieldStruct;
        }

        /// <summary>
        /// filter full list, return a list matching the value in strDocName
        /// </summary>
        /// <param name="objList">full list to search in</param>
        /// <param name="strDocName">document name to search for</param>
        /// <returns>filtered list of results</returns>
        public List<DocumentFieldStruct> FilterDocFieldStructList(List<DocumentFieldStruct> objList, String strDocName)
        {
            List<DocumentFieldStruct> objResultList = (from docfields in objList
                                                       where String.Compare(docfields.DocumentName, strDocName, true) == 0
                                                       select docfields).ToList();
            return objResultList;
        }

        /// <summary>
        /// Get document ID from table [OCRDocumentMaster]
        /// </summary>
        /// <param name="strCountryCode">market country code</param>
        /// <param name="strDocumentName">document definition name in ABBYY</param> 
        /// <returns>document Id for a particular document name</returns>
        public long GetDocumentId(string strCountryCode, string strDocumentName)
        {
            // return int variable
            long id = 0;

            try
            {

                using (SqlConnection conn = new SqlConnection(_dbConnectionString))
                {
                    String strSql = @"SELECT [DocumentId] FROM [OCRDocumentMaster] 
                                    WHERE MarketName=@marketName AND DocumentName=@documentName";
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    var objMarketName = new SqlParameter("marketName", SqlDbType.VarChar, 20);
                    var objDocumentName = new SqlParameter("documentName", SqlDbType.VarChar, 150);

                    objMarketName.Value = strCountryCode;
                    objDocumentName.Value = strDocumentName;

                    cmd.Parameters.Add(objMarketName);
                    cmd.Parameters.Add(objDocumentName);

                    Object objReturn = cmd.ExecuteScalar();

                    if (objReturn != null)
                    {
                        id = Convert.ToInt64(objReturn);
                    }

                    cmd.Dispose();
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                utility.WriteMessage(String.Format("[OCRCommonLib] GetDocumentId method error encountered {0}", ex.ToString()));
            }

            return id;
        }

        /// <summary>
        /// Get match percentage between OCR and CMS value
        /// </summary>
        /// <param name="ocrValue">OCR value</param>
        /// <param name="cmsValue">CMS value</param> 
        /// <returns>match percentage</returns>
        public int GetMatchPercentage(string ocrValue, string cmsValue)
        {
            // return int variable
            int percentage = 0;

            try
            {
                using (SqlConnection conn = new SqlConnection(_dbConnectionString))
                {
                    String strSql = @"SELECT [dbo].[GetPercentageOfTwoStringMatching](@ocr, @cms)";
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    var objOCR = new SqlParameter("ocr", SqlDbType.VarChar, 20);
                    var objCMS = new SqlParameter("cms", SqlDbType.VarChar, 150);

                    objOCR.Value = ocrValue;
                    objCMS.Value = cmsValue;

                    cmd.Parameters.Add(objOCR);
                    cmd.Parameters.Add(objCMS);

                    Object objReturn = cmd.ExecuteScalar();

                    if (objReturn != null)
                    {
                        percentage = Convert.ToInt16(objReturn);
                    }

                    cmd.Dispose();
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                utility.WriteMessage(String.Format("[OCRCommonLib] GetMatchPercentage method error encountered {0}", ex.ToString()));
            }

            return percentage;
        }

        /// <summary>
        /// Insert transaction record to [OCRBatchTransaction]
        /// </summary>
        /// <param name="batchId">ABBYY batchID</param>
        /// <param name="marketName">market country code</param>
        /// <param name="applicationNumber">ABBYY batch name</param>
        /// <param name="documentId">document ID</param>
        /// <param name="documentName">document definition name</param>
        /// <param name="fieldName">field name</param>
        /// <param name="ocrValue">OCR value</param>
        /// <param name="cmsValue">CMS value</param>
        /// <param name="isMatched">IsMatched flag</param>
        /// <param name="username">username who updated the batch (after verification)</param>
        /// <param name="txnStatus">status in OCRBatchTransaction</param>
        /// <returns>true if insert is successful</returns>
        public Boolean InsertOCRBatchTransaction(int batchId, string marketName, string applicationNumber, long documentId, string documentName,
            string fieldName, string ocrValue, string cmsValue, bool isMatched, string username, string txnStatus)
        {
            Boolean isSuccess = false;
            try
            {
                // get MatchPercentage FIRSt!
                int matchPercentage = 0;
                if (isMatched)
                {
                    matchPercentage = 100;
                }
                else if (!String.IsNullOrEmpty(cmsValue))
                {
                    matchPercentage = GetMatchPercentage(ocrValue, cmsValue);
                }

                using (SqlConnection conn = new SqlConnection(_dbConnectionString))
                {
                    string strSql = @"INSERT INTO [dbo].[OCRBatchTransaction]
                                       ([BatchId]
                                       ,[MarketName]
                                       ,[ApplicationNumber]
                                       ,[DocumentId]
                                       ,[DocumentName]
                                       ,[FieldName]
                                       ,[OCRValue]
                                       ,[CMSValue]
                                       ,[IsMatched]
                                       ,[MatchPercentage]
                                       ,[Username]
                                       ,[Status]
                                       ,[CreatedDate] )
                                 VALUES
                                       (@batchId
                                       ,@marketName
                                       ,@applicationNumber
                                       ,@documentId
                                       ,@documentName
                                       ,@fieldName
                                       ,@ocrValue
                                       ,@cmsValue
                                       ,@isMatched
                                       ,@matchPercentage
                                       ,@username
                                       ,@txnStatus
                                       ,@createdDate
                                       )";

                    conn.Open();
                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    var objBatchId = new SqlParameter("batchId", SqlDbType.BigInt);
                    var objMarketName = new SqlParameter("marketName", SqlDbType.VarChar, 20);
                    var objApplicationNumber = new SqlParameter("applicationNumber", SqlDbType.NVarChar, 150);
                    var objDocumentId = new SqlParameter("documentId", SqlDbType.BigInt);
                    var objDocumentName = new SqlParameter("documentName", SqlDbType.NVarChar, 150);
                    var objFieldName = new SqlParameter("fieldName", SqlDbType.NVarChar, 150);
                    var objOcrValue = new SqlParameter("ocrValue", SqlDbType.NVarChar, 200);
                    var objCmsValue = new SqlParameter("cmsValue", SqlDbType.NVarChar, 200);
                    var objMatched = new SqlParameter("isMatched", SqlDbType.Bit);
                    var objMatchPercentage = new SqlParameter("matchPercentage", SqlDbType.Int);
                    var objUsername = new SqlParameter("username", SqlDbType.NVarChar, 150);
                    var objStatus = new SqlParameter("txnStatus", SqlDbType.NVarChar, 150);
                    var objCreatedDate = new SqlParameter("createdDate", SqlDbType.DateTime);
                    objBatchId.Value = batchId;
                    objMarketName.Value = marketName;
                    objApplicationNumber.Value = applicationNumber;
                    objDocumentId.Value = documentId;
                    objDocumentName.Value = documentName;
                    objFieldName.Value = fieldName;
                    objOcrValue.Value = ocrValue;
                    objCmsValue.Value = cmsValue;
                    objMatched.Value = isMatched;
                    objMatchPercentage.Value = matchPercentage;
                    objUsername.Value = username;
                    objStatus.Value = txnStatus;

                    objCreatedDate.Value = DateTime.Now;

                    cmd.Parameters.Add(objBatchId);
                    cmd.Parameters.Add(objMarketName);
                    cmd.Parameters.Add(objApplicationNumber);
                    cmd.Parameters.Add(objDocumentId);
                    cmd.Parameters.Add(objDocumentName);
                    cmd.Parameters.Add(objFieldName);
                    cmd.Parameters.Add(objOcrValue);
                    cmd.Parameters.Add(objCmsValue);
                    cmd.Parameters.Add(objMatched);
                    cmd.Parameters.Add(objMatchPercentage);
                    cmd.Parameters.Add(objUsername);
                    cmd.Parameters.Add(objStatus);
                    cmd.Parameters.Add(objCreatedDate);

                    cmd.ExecuteNonQuery();
                    conn.Close();

                    utility.WriteMessage(String.Format("Successfully inserted {0} in OCRBatchTransaction", fieldName));
                    isSuccess = true;
                }
            }
            catch (Exception ex)
            {
                utility.WriteMessage(String.Format("[OCRCommonLib] InsertOCRBatchTransaction method error encountered {0}", ex.ToString()));
            }

            return isSuccess;
        }

        /// <summary>
        /// Get the CMS data based on contractNumber and countryCode
        /// </summary>
        /// <param name="contractNumber">Contract Number</param>
        /// <param name="countryCode">2 letter country code for the market</param>
        /// <returns>Returns CMS JSON data in string format</returns>
        public string GetCMSByContractNumber(string contractNumber, string countryCode)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(_dbConnectionString))
                {

                    String strSql = "select ISNULL(JSON,'') as JSON from CustomCMS where ContractNumber = @applicationNumber AND MarketName = @market";
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    var objApplicationNumber = new SqlParameter("applicationNumber", SqlDbType.VarChar, 50);
                    var objMarket = new SqlParameter("market", SqlDbType.VarChar, 20);
                    objApplicationNumber.Value = contractNumber;
                    objMarket.Value = countryCode;
                    cmd.Parameters.Add(objApplicationNumber);
                    cmd.Parameters.Add(objMarket);
                    string json = cmd.ExecuteScalar().ToString();

                    return json;
                }
            }
            catch (Exception ex)
            {
                utility.WriteMessage(String.Format("[OCRCommonLib] GetCMSByContractNumber method error encountered {0}", ex.ToString()));
            }

            return string.Empty;
        }

        /// <summary>
        /// Insert upload details to OCRLiveLinkTransaction
        /// </summary>
        /// <param name="batchId">ABBYY batchID</param>
        /// <param name="marketName">market country code</param>
        /// <param name="applicationNumber">market unique identifier</param>
        /// <param name="documentTile">Document Section Name- only for AU</param>
        /// <param name="documentType">DMS Document Type- only for AU</param>
        /// <param name="keyPhrase">DMS Key Phrase- only for AU</param>
        /// <param name="TeamName">DMS Team name- only for AU</param>
        /// <param name="FileStamp">filename and extension</param>
        /// <param name="FilePath">full path</param>
        /// <param name="status">DMS upload status</param>
        /// <param name="ErrorMessage">DMS error message</param>
        /// <returns>
        /// Returns true if successfully executed insert statement.
        /// Returns false if method encountered error
        /// </returns>
        public Boolean InsertLiveLinkTransaction(int batchId, string marketName, string applicationNumber,
            string documentTile, string documentType, string keyPhrase, string TeamName, string FileStamp, string FilePath,
            string status, string ErrorMessage)
        {
            Boolean isSuccess = false;
            try
            {
                using (SqlConnection conn = new SqlConnection(_dbConnectionString))
                {
                    string strSql = @"INSERT INTO [dbo].[OCRLiveLinkTransaction]
                                           ([BatchId]
                                           ,[MarketName]
                                           ,[AppNo]
                                           ,[DocumentTitle]
                                           ,[DocumentType]
                                           ,[KeyPhrase]
                                           ,[TeamName]
                                           ,[FileStamp]
                                           ,[FilePath]  
                                           ,[Status]
                                           ,[ErrorMessage]  
                                           ,[CreatedDate])
                                     VALUES
                                           (@batchId
                                           ,@marketName
                                           ,@appNo
                                           ,@documentTitle
                                           ,@documentType
                                           ,@keyPhrase
                                           ,@teamName
                                           ,@fileStamp
                                           ,@filePath  
                                           ,@status 
                                           ,@errorMessage 
                                           ,@createdDate)
                                       ";

                    conn.Open();
                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    var objBatchId = new SqlParameter("batchId", SqlDbType.BigInt);
                    var objMarketName = new SqlParameter("marketName", SqlDbType.VarChar, 10);
                    var objApplicationNumber = new SqlParameter("appNo", SqlDbType.VarChar, 100);
                    var objDocumentTitle = new SqlParameter("documentTitle", SqlDbType.VarChar, 500);
                    var objDocumentType = new SqlParameter("documentType", SqlDbType.VarChar, 500);
                    var objKeyPhrase = new SqlParameter("keyPhrase", SqlDbType.VarChar, 500);
                    var objTeamName = new SqlParameter("teamName", SqlDbType.VarChar, 500);
                    var objFileStamp = new SqlParameter("fileStamp", SqlDbType.VarChar, 500);
                    var objFilePath = new SqlParameter("filePath", SqlDbType.VarChar, 500);
                    var objStatus = new SqlParameter("status", SqlDbType.VarChar, 500);
                    var objErrorMessage = new SqlParameter("errorMessage", SqlDbType.VarChar, -1);
                    var objCreatedDate = new SqlParameter("createdDate", SqlDbType.DateTime);
                    objBatchId.Value = batchId;
                    objMarketName.Value = marketName;
                    objApplicationNumber.Value = applicationNumber;
                    objDocumentTitle.Value = documentTile;
                    objDocumentType.Value = documentType;
                    objKeyPhrase.Value = keyPhrase;
                    objTeamName.Value = TeamName;
                    objFileStamp.Value = FileStamp;
                    objFilePath.Value = FilePath;
                    objStatus.Value = status;
                    objErrorMessage.Value = ErrorMessage;
                    objCreatedDate.Value = DateTime.Now;

                    cmd.Parameters.Add(objBatchId);
                    cmd.Parameters.Add(objMarketName);
                    cmd.Parameters.Add(objApplicationNumber);
                    cmd.Parameters.Add(objDocumentTitle);
                    cmd.Parameters.Add(objDocumentType);
                    cmd.Parameters.Add(objKeyPhrase);
                    cmd.Parameters.Add(objTeamName);
                    cmd.Parameters.Add(objFileStamp);
                    cmd.Parameters.Add(objFilePath);
                    cmd.Parameters.Add(objStatus);
                    cmd.Parameters.Add(objErrorMessage);
                    cmd.Parameters.Add(objCreatedDate);

                    cmd.ExecuteNonQuery();
                    conn.Close();

                    utility.WriteMessage(String.Format("Successfully inserted {0} in OCRBatchTransaction", FileStamp));
                    isSuccess = true;
                }
            }
            catch (Exception ex)
            {
                utility.WriteMessage(String.Format("[OCRCommonLib] InsertOCRBatchTransaction method error encountered {0}", ex.ToString()));
            }

            return isSuccess;
        }

        /// <summary>
        /// Get the LatestSequenceNumber Object and lock that record to true
        /// </summary>
        /// <param name="marketName">marketName</param>
        /// <param name="sequenceGroupName">sequenceGroupName</param>
        /// <param name="preText">preText</param>
        /// <returns></returns>
        public OCRSequenceNumberDTO GettheLatestSequenceNumber(string marketName, string sequenceGroupName, string preText)
        {
            OCRSequenceNumberDTO ocrSequenceNumber = new OCRSequenceNumberDTO();

            try
            {
                using (SqlConnection conn = new SqlConnection(_dbConnectionString))
                {

                    #region [Get the Record]
                    conn.Open();
                    StringBuilder selectQuery = new StringBuilder();
                    selectQuery.Append("SELECT * FROM [dbo].[OCRSequenceNumber] ");
                    selectQuery.Append("WHERE MarketName = @MarketName ");
                    selectQuery.Append("AND SequenceGroupName = @SequenceGroupName ");
                    selectQuery.Append("AND PreText = @PreText ");

                    SqlCommand cmdGet = new SqlCommand(selectQuery.ToString(), conn);
                    var objMarketNameParam = new SqlParameter("MarketName", SqlDbType.NVarChar, 50);
                    objMarketNameParam.Value = marketName;
                    cmdGet.Parameters.Add(objMarketNameParam);

                    var objContractNumberParam = new SqlParameter("SequenceGroupName", SqlDbType.NVarChar, 50);
                    objContractNumberParam.Value = sequenceGroupName;
                    cmdGet.Parameters.Add(objContractNumberParam);

                    var objPreTextParam = new SqlParameter("PreText", SqlDbType.NVarChar, 50);
                    objPreTextParam.Value = preText;
                    cmdGet.Parameters.Add(objPreTextParam);

                    SqlDataReader objReader = cmdGet.ExecuteReader();

                    while (objReader.Read())
                    {
                        ocrSequenceNumber = new OCRSequenceNumberDTO
                        {
                            MarketName = objReader["MarketName"].ToString(),
                            SequenceGroupName = objReader["SequenceGroupName"].ToString(),
                            PreText = objReader["PreText"].ToString(),
                            Separator = objReader["Separator"].ToString(),
                            LatestSequenceNumber = Convert.ToInt32(objReader["LatestSequenceNumber"]),
                            IncrementBy = Convert.ToInt32(objReader["IncrementBy"]),
                            DecimalFormatSpecifier = objReader["DecimalFormatSpecifier"].ToString(),
                            CreatedDate = Convert.ToDateTime(objReader["CreatedDate"]),
                            IsLock = Convert.ToBoolean(objReader["IsLock"])
                        };
                    }
                    conn.Close();
                    #endregion

                    #region [Update the Record IsLock ]
                    conn.Open();
                    StringBuilder UpdateQuery = new StringBuilder();
                    UpdateQuery.Append("UPDATE [dbo].[OCRSequenceNumber] ");
                    UpdateQuery.Append("SET [UpdatedDate] = @UpdatedDate, ");
                    UpdateQuery.Append("[IsLock] = @IsLock ");
                    UpdateQuery.Append("WHERE [MarketName] = @MarketName ");
                    UpdateQuery.Append("AND [SequenceGroupName] = @SequenceGroupName ");
                    UpdateQuery.Append("AND [PreText] = @PreText ");

                    SqlCommand cmdUpdate = new SqlCommand(UpdateQuery.ToString(), conn);
                    var objMarketName = new SqlParameter("MarketName", SqlDbType.NVarChar, 20);
                    objMarketName.Value = marketName;
                    cmdUpdate.Parameters.Add(objMarketName);

                    var objSequenceGroupName = new SqlParameter("SequenceGroupName", SqlDbType.NVarChar, 50);
                    objSequenceGroupName.Value = sequenceGroupName;
                    cmdUpdate.Parameters.Add(objSequenceGroupName);

                    var objPreText = new SqlParameter("PreText", SqlDbType.NVarChar, 50);
                    objPreText.Value = preText;
                    cmdUpdate.Parameters.Add(objPreText);

                    var objUpdatedDate = new SqlParameter("UpdatedDate", SqlDbType.DateTime);
                    objUpdatedDate.Value = DateTime.Now;
                    cmdUpdate.Parameters.Add(objUpdatedDate);

                    var objIsLock = new SqlParameter("IsLock", SqlDbType.Bit);
                    objIsLock.Value = 1;
                    cmdUpdate.Parameters.Add(objIsLock);

                    cmdUpdate.ExecuteNonQuery();
                    conn.Close();
                    #endregion

                }
            }
            catch (Exception exc)
            {
                utility.WriteMessage("GettheLatestSequenceNumber DB Error is : " + exc.ToString());
            }

            return ocrSequenceNumber;
        }

        /// <summary>
        /// create SequenceNumber
        /// </summary>
        /// <param name="ocrSequenceNumber">ocrSequenceNumber Objec</param>
        /// <returns></returns>
        public bool CreateSequenceNumber(OCRSequenceNumberDTO ocrSequenceNumber)
        {
            Boolean isSuccess = false;
            try
            {
                using (SqlConnection conn = new SqlConnection(_dbConnectionString))
                {
                    string strSql = @"INSERT INTO [dbo].[OCRSequenceNumber]
                                           (
                                            [MarketName]
                                            ,[SequenceGroupName]
                                            ,[PreText]
                                            ,[Separator]
                                            ,[LatestSequenceNumber]
                                            ,[IncrementBy]
                                            ,[CreatedDate]
                                            ,[DecimalFormatSpecifier]
                                            ,[IsLock]
                                            )
                                     VALUES
                                           (
                                            @MarketName
                                           ,@SequenceGroupName
                                           ,@PreText
                                           ,@Separator
                                           ,@LatestSequenceNumber
                                           ,@IncrementBy
                                           ,@CreatedDate
                                           ,@DecimalFormatSpecifier
                                           ,@IsLock
                                            )
                                       ";

                    conn.Open();
                    SqlCommand cmdCreate = new SqlCommand(strSql, conn);
                    var objMarketName = new SqlParameter("MarketName", SqlDbType.NVarChar , 20);
                    objMarketName.Value = ocrSequenceNumber.MarketName;
                    cmdCreate.Parameters.Add(objMarketName);

                    var objSequenceGroupName = new SqlParameter("SequenceGroupName", SqlDbType.NVarChar,50);
                    objSequenceGroupName.Value = ocrSequenceNumber.SequenceGroupName;
                    cmdCreate.Parameters.Add(objSequenceGroupName);

                    var objPreText = new SqlParameter("PreText", SqlDbType.NVarChar, 50);
                    objPreText.Value = ocrSequenceNumber.PreText;
                    cmdCreate.Parameters.Add(objPreText);

                    var objSeparator = new SqlParameter("Separator", SqlDbType.NVarChar, 5);
                    objSeparator.Value = ocrSequenceNumber.Separator;
                    cmdCreate.Parameters.Add(objSeparator);

                    var objLatestSequenceNumber = new SqlParameter("LatestSequenceNumber", SqlDbType.Int);
                    objLatestSequenceNumber.Value = ocrSequenceNumber.LatestSequenceNumber;
                    cmdCreate.Parameters.Add(objLatestSequenceNumber);

                    var objIncrementBy = new SqlParameter("IncrementBy", SqlDbType.Int);
                    objIncrementBy.Value = ocrSequenceNumber.IncrementBy;
                    cmdCreate.Parameters.Add(objIncrementBy);

                    var objCreatedDate = new SqlParameter("CreatedDate", SqlDbType.DateTime);
                    objCreatedDate.Value = ocrSequenceNumber.CreatedDate;
                    cmdCreate.Parameters.Add(objCreatedDate);

                    var objDecimalFormatSpecifier = new SqlParameter("DecimalFormatSpecifier", SqlDbType.NVarChar);
                    objDecimalFormatSpecifier.Value = ocrSequenceNumber.DecimalFormatSpecifier;
                    cmdCreate.Parameters.Add(objDecimalFormatSpecifier);

                    var objIsLock = new SqlParameter("IsLock", SqlDbType.Bit);
                    objIsLock.Value = ocrSequenceNumber.IsLock;
                    cmdCreate.Parameters.Add(objIsLock);

                    cmdCreate.ExecuteNonQuery();
                    conn.Close();

                    utility.WriteMessage(String.Format("Successfully inserted {0} in OCRSequenceNumber", ocrSequenceNumber.PreText ));
                    isSuccess = true;
                }
            }
            catch (Exception ex)
            {
                utility.WriteMessage("CreateSequenceNumber DB Error is : " + ex.ToString());
            }

            return isSuccess;
        }

        /// <summary>
        /// Update LatestSequenceNumber , and release the lock column to false.
        /// </summary>
        /// <param name="ocrSequenceNumber"></param>
        /// <returns></returns>
        public bool UpdateSequenceNumber(OCRSequenceNumberDTO ocrSequenceNumber)
        {
            Boolean isSuccess = false;
            try
            {
                using (SqlConnection conn = new SqlConnection(_dbConnectionString))
                {
                    string strSql = @"UPDATE [dbo].[OCRSequenceNumber]
                                      SET [LatestSequenceNumber] = @LatestSequenceNumber,
                                          [UpdatedDate] = @UpdatedDate,
                                          [IsLock] = @IsLock
                                      WHERE [MarketName] = @MarketName
                                      AND [SequenceGroupName] = @SequenceGroupName
                                      AND [PreText] = @PreText
                                       ";

                    conn.Open();
                    SqlCommand cmdUpdate = new SqlCommand(strSql, conn);
                    var objMarketName = new SqlParameter("MarketName", SqlDbType.NVarChar ,50);
                    objMarketName.Value = ocrSequenceNumber.MarketName;
                    cmdUpdate.Parameters.Add(objMarketName);

                    var objSequenceGroupName = new SqlParameter("SequenceGroupName", SqlDbType.NVarChar ,50);
                    objSequenceGroupName.Value = ocrSequenceNumber.SequenceGroupName;
                    cmdUpdate.Parameters.Add(objSequenceGroupName);

                    var objPreText = new SqlParameter("PreText", SqlDbType.NVarChar, 50);
                    objPreText.Value = ocrSequenceNumber.PreText;
                    cmdUpdate.Parameters.Add(objPreText);

                    var objLatestSequenceNumber = new SqlParameter("LatestSequenceNumber", SqlDbType.Int);
                    objLatestSequenceNumber.Value = ocrSequenceNumber.LatestSequenceNumber;
                    cmdUpdate.Parameters.Add(objLatestSequenceNumber);

                    var objUpdatedDate = new SqlParameter("UpdatedDate", SqlDbType.DateTime);
                    objUpdatedDate.Value = ocrSequenceNumber.UpdatedDate;
                    cmdUpdate.Parameters.Add(objUpdatedDate);

                    var objIsLock = new SqlParameter("IsLock", SqlDbType.Bit);
                    objIsLock.Value = ocrSequenceNumber.IsLock;
                    cmdUpdate.Parameters.Add(objIsLock);

                    cmdUpdate.ExecuteNonQuery();
                    conn.Close();

                    utility.WriteMessage(String.Format("Successfully Updated {0} in OCRSequenceNumber", ocrSequenceNumber.PreText));
                    isSuccess = true;
                }
            }
            catch (Exception ex)
            {
                utility.WriteMessage("UpdateSequenceNumber DB Error is : " + ex.ToString());
            }

            return isSuccess;
        }
    
    }
}
