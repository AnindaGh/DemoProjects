﻿
using OCRCommonLib.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCRCommonLib.DataAccess
{
    public interface IDBAccess
    {
        List<string> GetFieldList(string strCountryCode);

        List<DocumentFieldStruct> GetDocFieldStructList(String strCountryCode);

        List<DocumentFieldStruct> FilterDocFieldStructList(List<DocumentFieldStruct> objList, String strDocName);

        long GetDocumentId(string strCountryCode, string strDocumentName);

        int GetMatchPercentage(string ocrValue, string cmsValue);

        Boolean InsertOCRBatchTransaction(int batchId, string marketName, string applicationNumber, long documentId, string documentName,
            string fieldName, string ocrValue, string cmsValue, bool isMatched, string username, string txnStatus);

        string GetCMSByContractNumber(string contractNumber, string countryCode);

        Boolean InsertLiveLinkTransaction(int batchId, string marketName, string applicationNumber,
            string documentTile, string documentType, string keyPhrase, string TeamName, string FileStamp, string FilePath,
            string status, string ErrorMessage);

        OCRSequenceNumberDTO GettheLatestSequenceNumber(string marketName, string sequenceGroupName, string preText);

        bool CreateSequenceNumber(OCRSequenceNumberDTO ocrSequenceNumber);

        bool UpdateSequenceNumber(OCRSequenceNumberDTO ocrSequenceNumber);
    }
}
