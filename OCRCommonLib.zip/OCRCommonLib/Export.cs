﻿using ABBYY.FlexiCapture;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCRCommonLib
{
    /// <summary>
    /// 
    /// </summary>
    public class Export
    {
        Utility _utility;

        /// <summary>
        /// default constructor
        /// </summary> 
        public Export(string webServiceURL, string applicationLogName)
        {
            _utility = new Utility(webServiceURL, applicationLogName);
        }

        /// <summary>
        /// Exports ABBYY Documents to Searchable PDF
        /// </summary>
        /// <param name="batchRef">ABBYY instance of Batch class</param>
        /// <param name="docRef">ABBYY instance of Document class</param> 
        /// <param name="folderPath">folder to export the PDF document</param> 
        public void ExportToPdf(IBatch batchRef, IDocument docRef, string folderPath)
        {
            try
            {
                string imageFolderPath = folderPath + @"\" + batchRef.Name;
                if (!Directory.Exists(imageFolderPath)) Directory.CreateDirectory(imageFolderPath);

                // only grab recognized templates
                List<IPage> lstPages = new List<IPage>();
                foreach (IPage page in docRef.Pages)
                {
                    if (!string.IsNullOrEmpty(page.SectionName))
                        lstPages.Add(page);
                }

                // Normal pages (excluding Annex)
                AssembleRecognizedPages(lstPages, batchRef, imageFolderPath);
            }
            catch (Exception ex)
            {
                _utility.WriteMessage(String.Format("[OCRCommonLib] ExportToPdf method encountered an error {0}", ex.StackTrace));
            }
        }

        private void AssembleRecognizedPages(List<IPage> lstPages, IBatch batchRef, string imageFolderPath)
        {
            try
            {
                string newFileName = string.Empty;
                IDocument newDoc = null;
                string sectionName = "-1"; // mark as first instance in the loop

                foreach (IPage page in lstPages)
                {
                    if (!sectionName.ToLower().Equals(page.SectionName.ToLower()))
                    {
                        if (!sectionName.Equals("-1"))
                        {
                            newFileName = imageFolderPath + @"\" + sectionName + ".pdf";
                            SaveAbbyyDocument(newFileName, newDoc);
                        }

                        sectionName = page.SectionName;
                        newDoc = batchRef.CreateDocumentFromPage(0, page);
                    }
                    else
                    {
                        // Same Document Section
                        batchRef.MovePage(page.Document, newDoc, page.Index, newDoc.Pages.Count);
                    }
                }

                // save last sectionName
                if (!string.IsNullOrEmpty(sectionName))
                {
                    newFileName = imageFolderPath + @"\" + sectionName + ".pdf";
                    SaveAbbyyDocument(newFileName, newDoc);
                }
            }
            catch (Exception ex)
            {
                _utility.WriteMessage(String.Format("[OCRCommonLib] AssembleRecognizedPages method encountered an error {0}", ex.StackTrace));
            }

        }

        private void AssembleAnnexPages(List<IPage> lstPages, IBatch batchRef, string imageFolderPath)
        {
            try
            {
                // Annex
                string newFileName = string.Empty;
                IDocument newDoc = null;
                string sectionName = "-1"; // mark as first instance in the loop

                foreach (IPage page in lstPages)
                {
                    if (string.IsNullOrEmpty(page.SectionName))
                    {
                        if (sectionName.Equals("-1"))
                        {
                            sectionName = "Annex";
                            newDoc = batchRef.CreateDocumentFromPage(0, page);
                        }
                        else
                        {
                            batchRef.MovePage(page.Document, newDoc, page.Index, newDoc.Pages.Count);
                        }
                    }
                }
                if (!sectionName.Equals("-1"))
                {
                    newFileName = imageFolderPath + @"\" + sectionName + ".pdf";
                    SaveAbbyyDocument(newFileName, newDoc);
                }
            }
            catch (Exception ex)
            {
                _utility.WriteMessage(String.Format("[OCRCommonLib] AssembleAnnexPages method encountered an error {0}", ex.StackTrace));
            }
        }

        private void SaveAbbyyDocument(string newFileName, IDocument newDoc)
        {
            try
            {
                IExportImageSavingOptions exportSettings = FCTools.NewImageSavingOptions();
                exportSettings.Format = "pdf-s";
                exportSettings.Resolution = 300;
                exportSettings.AddProperFileExt = true;
                exportSettings.ShouldOverwrite = true;
                newDoc.SaveAs(newFileName, exportSettings);
            }
            catch (Exception ex)
            {
                _utility.WriteMessage(String.Format("[OCRCommonLib] SaveAbbyyDocument method encountered an error {0}", ex.StackTrace));
            }
        }
    }
}
