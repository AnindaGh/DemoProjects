﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OCRCommonLib.DataAccess;

namespace OCRCommonLibNUnit.DataAccess
{
    public class DBAccessTests
    {

        protected String _LogFileApiUrl;
        protected String _LogFileAppName;
        protected String _DBConnEncrypted;
        protected String _countryCode;
        protected DBAccess _DBAccess;

        [SetUp]
        public void Setup()
        {
            _LogFileApiUrl = "http://localhost/OCRCommonSvc/api/LogEntry";
            _LogFileAppName = "ZAFlexiLog";
            _countryCode = "ZA";
            _DBConnEncrypted = "rdUMzsvjSd8xOy5aGbVQekiE60VFwrPCkHgrF0u0Mo0iGY6dBikYwLp1cLAwGVJTQpuIljt6o21wmpViXNrgGOy530FTm7NSNUp5aB69wU5Mmy1BsobhY9UshayFZ/7vBJ2Q8VCiT2M08eTOY+vWnR3jOKIoqYb+UWarYWUSRmNhvQWEiyTBztwCZIZxxXrS97vqfBGiAdZ0Pvr0Lfwfyi23qHr5KbDIeWhzyqJAy6QdRjpjsw0SGF8XDm8p5frf";
            _DBAccess = new DBAccess(_DBConnEncrypted, _LogFileAppName, _LogFileApiUrl, _countryCode);
        }

        [Test]
        public void GetFieldList_SuccessTest()
        {
            List<String> objList = _DBAccess.GetFieldList("ZA");
            Assert.Greater(objList.Count, 0);
        }

        [Test]
        public void GetFieldList_ErrorTest()
        {
            List<String> objList = _DBAccess.GetFieldList("XX");
            Assert.AreEqual(0, objList.Count);
        }

        [Test]
        public void GetDocFieldStructList_ErrorTest()
        {
            List<DocumentFieldStruct> objList = _DBAccess.GetDocFieldStructList("XX");
            Assert.AreEqual(0, objList.Count);
        }

        [Test]
        public void FilterDocFieldStructList_SuccessTest()
        {
            List<DocumentFieldStruct> objList = _DBAccess.GetDocFieldStructList("ZA");
            Assert.Greater(objList.Count, 0);
            String strDocName = "Contract";
            List<DocumentFieldStruct> objResultList = _DBAccess.FilterDocFieldStructList(objList, strDocName);
            Assert.Greater(objResultList.Count, 0);
        }

        [Test]
        public void FilterDocFieldStructList_ErrorTest()
        {
            List<DocumentFieldStruct> objList = _DBAccess.GetDocFieldStructList("ZA");
            Assert.Greater(objList.Count, 0);
            String strDocName = "ABC";
            List<DocumentFieldStruct> objResultList = _DBAccess.FilterDocFieldStructList(objList, strDocName);
            Assert.AreEqual(0, objResultList.Count);
        }

        [TestCase("ZA", "XX")]
        [TestCase("XX", "Contract")]
        public void GetDocumentID_ErrorTest(String strCountry, String strDocName)
        {
            long iDocID = _DBAccess.GetDocumentId(strCountry, strDocName);
            Assert.AreEqual(0, iDocID);
        }

        [TestCase("ZA", "Contract")]
        public void GetDocumentID_SuccessTest(String strCountry, String strDocName)
        {
            long iDocID = _DBAccess.GetDocumentId(strCountry, strDocName);
            Assert.Greater(iDocID, 0);
        }

        /* [Test]
        public void InsertOCRBatchTransaction_SuccessTest()
        {
            String strDocName = "Contract";
            Boolean isSuccess = _DBAccess.InsertOCRBatchTransaction(999, "ZA", "1234", 43, strDocName, "ContractNumber", "1234", "12",
                    true, "", "Post Recognition");
            Assert.AreEqual(true, isSuccess);
        } */

    }
}
