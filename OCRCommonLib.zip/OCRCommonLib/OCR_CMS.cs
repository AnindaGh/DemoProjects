﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCRCommonLib
{
    public class OCR_CMS
    {
        public OCR_CMS(string CmsFieldName, string OcrFieldName, string OcrFieldValue, string OcrCheckBoxFieldName)
        {
            _cmsFieldName = CmsFieldName;
            _ocrFieldName = OcrFieldName;
            _ocrFieldValue = OcrFieldValue;
            _ocrCheckBoxFieldName = OcrCheckBoxFieldName;
        }

        private string _cmsFieldName;
        public string CmsFieldName
        {
            get { return _cmsFieldName; }
            set { _cmsFieldName = value; }
        }

        private string _cmsFieldValue;
        public string CmsFieldValue
        {
            get { return _cmsFieldValue; }
            set { _cmsFieldValue = value; }
        }

        private string _ocrFieldName;
        public string OcrFieldName
        {
            get { return _ocrFieldName; }
            set { _ocrFieldName = value; }
        }

        private string _ocrFieldValue;
        public string OcrFieldValue
        {
            get { return _ocrFieldValue; }
            set { _ocrFieldValue = value; }
        }

        private string _ocrCheckBoxFieldName;
        public string OcrCheckBoxFieldName
        {
            get { return _ocrCheckBoxFieldName; }
            set { _ocrCheckBoxFieldName = value; }
        }

        private int _ocrCheckBoxFieldValue;
        public int OcrCheckBoxFieldValue
        {
            get { return _ocrCheckBoxFieldValue; }
            set { _ocrCheckBoxFieldValue = value; }
        }
    }
}
