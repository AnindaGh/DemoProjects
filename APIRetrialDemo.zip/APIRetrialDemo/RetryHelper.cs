﻿using System;
using System.Collections.Generic;
using System.Text;

namespace APIRetrialDemo
{
    public static class RetryHelper
    {
        public static void Retry(int retryTimes, Action operation,TimeSpan delay)
        {
            var attempts = 0;

            do
            {
                try
                {
                    attempts++;
                    Console.WriteLine("Attempt No :" + attempts);
                    operation();
                    break;
                }
                catch (Exception exc)
                {
                    if(attempts == retryTimes)
                    {
                        throw;
                    }
                }
            }
            while (true);
        }
    }
}
