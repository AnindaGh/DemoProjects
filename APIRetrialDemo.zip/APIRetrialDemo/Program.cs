﻿using Polly;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace APIRetrialDemo
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Calling RestAPI!");
            //int retryCounter = 0;

            //var policy = Policy.Handle<HttpRequestException>().RetryAsync(3);

            //await policy.ExecuteAsync(async () =>
            //{
            //    HttpClient client = new HttpClient();
            //    var result = await client.GetAsync("https://localhost:44360/weatherforecast");
            //    Console.WriteLine(await result.Content.ReadAsStringAsync());
            //});

            HttpClient client = new HttpClient();
            var retryAttempts = 3;

            var delay = TimeSpan.FromSeconds(5);
            RetryHelper.Retry(retryAttempts, () =>
            {
                //var result = await client.GetAsync("https://localhost:44360/weatherforecast/UserData");
                //Console.WriteLine(await result.Content.ReadAsStringAsync());
                throw new Exception();
            }, delay);


            //Retry.Do(()=> {
            //   var newResult = client.GetAsync("https://localhost:44360/weatherforecast/UserData");

            //}, TimeSpan.FromSeconds(1));

            Action<int, Exception> newFunc = new Action<int, Exception>(Console.WriteLine(" hhhh") ;
           // Exception ex = new Exception();
            RetryOperationHelper.ExecuteWithRetry(async () =>
            {
                await client.GetAsync("https://localhost:44360/weatherforecast/UserData");
            }, retryAttempts, delay, newFunc);




        }
    }
}
