﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterviewDemo
{
    public class TestDelegate
    {
        public delegate void myDelegate();

        public void fun1()
        {
            Console.WriteLine("fun1");
        }
        public void fun2()
        {
            Console.WriteLine("fun2");
        }

        public void fun3()
        {
            Console.WriteLine("fun3");
        }

    }
}
