﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterviewDemo
{
    public class TestingInterface : Test1, Test2
    {
        public int MyProperty { get; set; }

        public void test()
        {
            //throw new NotImplementedException();
            Console.WriteLine("testing interface");
        }

        void Test2.test()
        {
            throw new NotImplementedException();
        }
    }
}
