﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterviewDemo
{
    public class PrivateConstructorDemo
    {
        private PrivateConstructorDemo()
        {
            Console.WriteLine("Private Constructor calling");
        }

        public static void someMethod()
        {
            Console.WriteLine("someMethod");
        }
    }

    //public class ChildPrivateConstructorDemo : PrivateConstructorDemo
    //{

    //    //public ChildPrivateConstructorDemo()
    //    //{
    //    //    Console.WriteLine("Child of PV ctor");
    //    //}

    //    public void newMethod()
    //    {
    //        Console.WriteLine("new Method");
    //    }
    //}
}
