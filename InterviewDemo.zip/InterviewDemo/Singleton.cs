﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterviewDemo
{
    public sealed class Singleton
    {
        private static Singleton myInstance = null;
        private static int counter = 0;

        private Singleton()
        {
            counter++;
            Console.WriteLine("Instance created :" + counter);
        }

        public static Singleton myMethod()
        {
            if(myInstance == null)
            {
                myInstance = new Singleton();
            }
            
            Console.WriteLine("Counter Value : " + counter);
            return myInstance;
        }
    }
}
