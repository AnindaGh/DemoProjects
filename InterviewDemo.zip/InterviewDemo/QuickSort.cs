﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterviewDemo
{
    public class QuickSort
    {
        public void quickSort(int[] arr,int left,int right)
        {

        }
    }
}
