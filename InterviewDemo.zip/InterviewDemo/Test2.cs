﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterviewDemo
{
    interface Test2 
    {
        //enum testenum { a=1,b=2,c=3 };

        public int MyProperty { get; set; }
        void test();
    }
}
