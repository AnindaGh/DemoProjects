﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace InterviewDemo
{
    class Program
    {
        public delegate void SomeMethod();

        static Program()
        {
            Console.WriteLine("Static Program");
        }

        public Program()
        {
            Console.WriteLine("Program Ctor");
        }
        static void  Main(string[] args)
        {
            Console.WriteLine("Hello World!");
           // PrivateConstructorDemo.someMethod();
            //PrivateConstructorDemo obj = new PrivateConstructorDemo();
            //Console.WriteLine("Main");
            //Program ob = new Program();

            //TestClass obj = new TestClass();
            //obj.TestMethod();
            //var obj = Singleton.myMethod();
            //var obj2 = Singleton.myMethod();
            //if(obj == obj2)
            //{
            //    Console.WriteLine("Same Object");
            //}

            //Struct1 str1 = new Struct1();

            // public TestClass gameObj;
            //TestClass obj = Instantiate(gameObj);


            //TestDelegate objDelegate = new TestDelegate();

            //TestDelegate.myDelegate mD = new TestDelegate.myDelegate(objDelegate.fun1);

            //mD();

            //int i = 5;
            //double j = 10.0;
            //float k = 10.23F;
            //B objB = new B();
            //objB.abc(k);  


            //A objA = new B();
            //objA.abc(i);

            //List<SomeMethod> delList = new List<SomeMethod>();
            //for (int i = 0; i < 10; i++)
            //{
            //    delList.Add(delegate { Console.WriteLine(i); });
            //}

            //foreach (var del in delList)
            //{
            //    del();
            //}

            //double e = 2.718281828459045;
            //object o = e; // box
            //int ee = (int)(double)o;
            //Console.WriteLine("ee :" + ee);

            //List<string> ls = new List<string>();

            //ls.Add("hello");
            //ls.Add("wow");
            //ls.Add("where");
            //ls.Add("child");
            //ls.Add("hi");
            //ls.Add("tpt");

            //var result = ls.Where(x => x.StartsWith("w")); // get all values that start with w
            ////var result = ls.FirstOrDefault<string>(x=>x.Contains("hi")); // gets first string with value hi


            //List<int> li = new List<int>();

            //li.Add(1);
            //li.Add(2);
            //li.Add(4);
            //li.Add(4);
            //li.Add(5);
            //li.Add(5);
            //li.Add(7);
            //li.Add(8);

            ////var iresult = li.Distinct(); //gets all distinct values
            //var iresult = li.Where(x => x % 2 != 0).Distinct();



            //foreach (var val in result)
            //{
            //    Console.WriteLine(val);
            //}

            //string id = Process.GetCurrentProcess().Id.ToString();

            //dynamic d = 3;
            //Console.WriteLine(d);
            //d = d + "2";
            //Console.WriteLine(d);

            //string dueDate = "201126";
            //string dueDate2 = "20201127";
            ////DateTime dateTime = DateTime.ParseExact(dueDate, "yyyyMMdd", CultureInfo.InvariantCulture).AddDays(1);

            ////string newDate = dateTime.ToString("yyyy/MM/dd");
            //string newDate2 = DateTime.ParseExact(dueDate2, "yyyyMMdd", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd");


            //generic delegates
            //Func<int, int> func = (x => x * 5);
            // Func<int, int> func = new Func<int, int>(x=>x * 5);

            //int someval = func(20);

            //Action<int> action = (x => Console.WriteLine(x));
            //action(34);

            //Predicate<int> predicate = (x => x > 20);
            //bool bval = predicate(29);

            //List<int> intList = new List<int>();
            //intList.Add(5);
            //intList.Add(23);
            //intList.Add(29);

            //var newVal = intList.Find(predicate);

            //ArrayList arl = new ArrayList();
            //arl.Add(4);

            //CancellationTokenSource cts = new CancellationTokenSource();

            //var task = Task.Run(() => LongRunningMethod(cts.Token), cts.Token);
            ////task.Start();

            //Thread.Sleep(500);
            //Console.WriteLine("Do you want to Cancel? (Y/N)");
            //var key = Console.ReadLine();

            //if (key.Contains('y'))
            //{
            //    cts.Cancel();
            //}
            //else if (key.ToString() == "n")
            //{
            //    task.Wait();
            //}

            //Thread.Sleep(2000);
            //Console.WriteLine("Main Cancelled!");




            //Count file extensions and group it
            //List<string> fileList = new List<string>();

            //fileList.Add("abc.pdf");
            //fileList.Add("xyz.pdf");
            //fileList.Add("123.jpg");
            //fileList.Add("456.png");
            //fileList.Add("333.pdf");
            //fileList.Add("wer.jpg");


            ////var listofextensions = new List<string>() { ".pdf", ".jpg", ".png" };
            //var fileResult = fileList.Select(f => Path.GetExtension(f)).GroupBy(x => x, (f, e) => new
            //{
            //    Extension = f,
            //    count = e.Count()
            //});

            //var nwFileResult = fileList.Select(f => Path.GetExtension(f));

            //    //.GroupBy(x => x, (f, e) => new { Extension = f, Count = e.Count() });



            //foreach(var res in fileResult)
            //{
            //    Console.WriteLine("Extension : " + res.Extension);
            //    Console.WriteLine("Count : " + res.count);

            //}

            var task1 = SomeTaskfunction1();
            var task2 = SomeTaskfunction2();
            var task3 = SomeTaskfunction3();
            List<Task> TaskList = new List<Task>();

            TaskList.Add(task1);
            TaskList.Add(task2);
            TaskList.Add(task3);

            //Task.WhenAll(TaskList);

            //TestingInterface ti = new TestingInterface();
            //ti.test();

            //String Interpolation
            var name = "Aninda";
            Console.WriteLine($"Hello {name}");

            //Task x = CallMultipleAsyncTasks();

            Parallel.ForEach(TaskList, task => task.Start());
            ConcurrentBag<int> bag = new ConcurrentBag<int>();
            bag.Add(5);
            bag.Add(9);

            var items = new[] { "Aninda", "Roshan", "Rahul" };

            foreach(var item in items)
            {
                Console.WriteLine(item);
            }
            var newitem = items[0];

            switch (newitem)
            {
                case "Aninda": 
                    Console.WriteLine("Aninda");
                    break;
                case "Roshan":
                    Console.WriteLine("Roshan");
                    break;
                case "Rahul":
                    Console.WriteLine("Rahul");
                    break;
                case "xyz":
                    Console.WriteLine("xyz");
                    break;
                case "Ahmed":
                    Console.WriteLine("Ahmed");
                    break;
                case "Matilda":
                    Console.WriteLine("Matilda");
                    break;
                case "Ron":
                    Console.WriteLine("Ron");
                    break;
                default:
                    Console.WriteLine("Default");
                    break;


            }
        }


        static void LongRunningMethod(CancellationToken token)
        {
            Console.WriteLine("Inside Long Running Method");
            for (int i = 0; i < 1000; i++)
            {
                Thread.Sleep(1000);
                if (token.IsCancellationRequested)
                {
                    Console.WriteLine("Method Cancelled");
                    Thread.Sleep(100);
                    return;
                }
                Console.WriteLine("LongRunningMethod : " + i);
                
            }
            Console.WriteLine("Long Running Method end");
        }

        public async static Task<string> SomeTaskfunction1()
        {
            string result = "SomeTaskFunction1 called...";
            Thread.Sleep(3000);
            return result;

        }

        public async static Task<string> SomeTaskfunction2()
        {
            string result = "SomeTaskFunction2 called...";
            Thread.Sleep(10000);
            return result;

        }

        public async static Task<string> SomeTaskfunction3()
        {
            string result = "SomeTaskFunction3 called...";
            Thread.Sleep(20000);
            return result;

        }

        public async static Task CallMultipleAsyncTasks()
        {
            var a = await SomeTaskfunction1();
            var b = await SomeTaskfunction2();
            var c = await SomeTaskfunction3();

        }
    }
}
