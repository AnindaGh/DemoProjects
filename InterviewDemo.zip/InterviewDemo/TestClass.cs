﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterviewDemo
{
    public class TestClass
    {
        static TestClass()
        {
            Console.WriteLine("Static TestClass");
        }

        public TestClass()
        {
            Console.WriteLine("Normal TestClass");
        }

        public void TestMethod()
        {
            Console.WriteLine("test Method");
        }
    }
}
