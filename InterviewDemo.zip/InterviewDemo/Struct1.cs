﻿using System;
using System.Collections.Generic;
using System.Text;
using static InterviewDemo.Test1;

namespace InterviewDemo
{
    struct Struct1 : Test1
    {
        public void SomeMethod()
        {

        }
        public void test()
        {
            throw new NotImplementedException();
        }

       
    }


}
