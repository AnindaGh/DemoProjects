﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterviewDemo
{
    public class A
    {
        public void abc(int a)
        {
            Console.WriteLine("abc from A");
        }
    }

    public class B : A
    {
        public void abc(double b)
        {
            Console.WriteLine("abc from B");
        }

        public void abc(float c)
        {
            Console.WriteLine("abc from B.2");
        }
    }
}
