﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterviewDemo
{
    interface Test1
    {
        public delegate void SomeDelegate();
        void test();
    }
}
