﻿using FileTransferSFTPLib.Constant;
using FileTransferSFTPLib.DTO;
using FileTransferSFTPLib.Helper;
using log4net;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace FileTransferSFTPLib
{
    /// <summary>
    /// File Transfer Service class
    /// </summary>
    public class FileTransferService
    {

        protected ILog _Log;
        protected IFileTransferSFTP _fileTransferSFTP;
        protected FileTransferConfig _fileTransferConfig;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="objLog">Log</param>
        /// <param name="fileTransferConfig">File Transfer Config</param>
        /// <param name="fileTransferSFTP">FileTransferSFTP object </param>
        public FileTransferService(ILog objLog, FileTransferConfig fileTransferConfig,  IFileTransferSFTP fileTransferSFTP)
        {
            _Log = objLog;
            _fileTransferConfig = fileTransferConfig;
            _fileTransferSFTP = fileTransferSFTP;
        }

        /// <summary>
        /// Initial method to trigger File Transfer
        /// </summary>
        public void Run()
        {
            try
            {
                _Log.InfoFormat("File Transfer Batch service has started.");

                ProcessTransferFiles();

            }
            catch (Exception exc)
            {
                _Log.ErrorFormat("File Transfer service Error : {0}", exc.ToString());
            }
            finally
            {
                _Log.InfoFormat("File Transfer Batch service has stopped.");
            }
        }

        /// <summary>
        /// Process the File Transfers 
        /// Step 1: Get all the File Transfer Info list from relevant xml file.
        /// Step 2 : Process the upload / download based on the Order
        /// </summary>
        public void ProcessTransferFiles()
        {
            List<FileTransferInfo> listTransferInfo = GetFileTransferInfoList();
            
            if(listTransferInfo.Count > 0)
            {
                listTransferInfo = listTransferInfo.OrderBy(O => O.TransferOrder).ToList(); // Sort the TransferOrder setting.

                int sftpPort = int.Parse(_fileTransferConfig.SFTP_PORT);

                SftpClient sftpClient = _fileTransferSFTP.GetSftpClient(_fileTransferConfig.SFTP_HOST, sftpPort, _fileTransferConfig.SFTP_ENCRYPTEDUSERNAME, _fileTransferConfig.SFTP_ENCRYPTEDPASSWORD);

                sftpClient.Connect();

                _Log.InfoFormat("Connection Established");

                foreach(var transferInfo in listTransferInfo)
                {
                    _Log.InfoFormat("Note : {0}", transferInfo.Note );

                    if (transferInfo.TransferOption == FileTransferConstants.FILETRANSFER_DOWNLOAD)
                    {
                        _fileTransferSFTP.DownloadDirectoryFiles(sftpClient, transferInfo.UserFolderPath, transferInfo.ServerFolderPath, transferInfo.IsCopySubirectories, transferInfo.IsDeleteFilesFromOriginAfterTransfer);

                        _Log.InfoFormat("Files or folders Download completed");
                    }
                    else if (transferInfo.TransferOption == FileTransferConstants.FILETRANSFER_UPLOAD)
                    {
                        _fileTransferSFTP.UploadDirectoryFiles(sftpClient, transferInfo.ServerFolderPath, transferInfo.UserFolderPath, transferInfo.IsCopySubirectories, transferInfo.IsDeleteFilesFromOriginAfterTransfer);

                        _Log.InfoFormat("Files or folders Upload completed");
                    }
                }      

                sftpClient.Dispose();

                _Log.InfoFormat("Connection closed");
            }            
        }

        /// <summary>
        /// Get all the File Transfer Info list from relevant xml file.
        /// </summary>
        /// <returns></returns>
        public List<FileTransferInfo> GetFileTransferInfoList()
        {
            List<FileTransferInfo> listTransferInfo = new List<FileTransferInfo>();

            XmlSerializer serializer = new XmlSerializer(typeof(List<FileTransferInfo>));

            using (StreamReader reader = new StreamReader(_fileTransferConfig.FILE_TRANSFER_INFO))
            {
                listTransferInfo = (List<FileTransferInfo>)serializer.Deserialize(reader);                
            }

            _Log.InfoFormat("File Transfer count is : {0}", listTransferInfo.Count());

            return listTransferInfo;
        }




    }
}
