﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileTransferSFTPLib.Constant
{

    public class FileTransferConstants
    {

        public const string SFTP_HOST = "SftpHost";
        public const string SFTP_PORT = "SftpPort";
        public const string SFTP_ENCRYPTEDUSERNAME = "SftpEncryptedUsername";
        public const string SFTP_ENCRYPTEDPASSWORD = "SftpEncryptedPassword"; 
        public const string FILE_TRANSFER_INFO_UPLOAD = "FileTransferInfo_upload";
        public const string FILE_TRANSFER_INFO_DOWNLOAD = "FileTransferInfo_download";

        public static string FILETRANSFER_UPLOAD = "Upload";
        public static string FILETRANSFER_DOWNLOAD = "Download";

    }
}
