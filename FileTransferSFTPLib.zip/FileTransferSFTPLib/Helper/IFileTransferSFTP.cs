﻿using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileTransferSFTPLib.Helper
{
    public interface IFileTransferSFTP
    {
        /// <summary>
        /// Initializes a new instance of the SftpClient class.
        /// </summary>
        /// <param name="host">Host address</param>
        /// <param name="port">Port number</param>
        /// <param name="encryptedUsername">Encrypted Username</param>
        /// <param name="encryptedPassword">Encrypted Password</param>
        /// <returns></returns>
        SftpClient GetSftpClient(string host, int port, string encryptedUsername, string encryptedPassword);

        /// <summary>
        /// Download the files from User server to our server
        /// </summary>
        /// <param name="sftpClient">SftpClient Object</param>
        /// <param name="userPath"></param>
        /// <param name="serverPath"></param>
        /// <param name="isCopySubDirectories"></param>
        /// <param name="isDeleteFilesFromOriginAfterTransfer">If true delete from origin path after Transfer the file</param>
        void DownloadDirectoryFiles(SftpClient sftpClient, string userPath, string serverPath, bool isCopySubDirectories, bool isDeleteFilesFromOriginAfterTransfer);

        /// <summary>
        /// Upload the files from our server to user side
        /// </summary>
        /// <param name="sftpClient">SftpClient Object</param>
        /// <param name="serverPath">Our server Path</param>
        /// <param name="userPath">User path</param>
        /// <param name="isCopySubDirectories">if true upload the sub directories also</param>
        /// <param name="isDeleteFilesFromOriginAfterTransfer">If true delete from origin path after Transfer the file</param>
        void UploadDirectoryFiles(SftpClient sftpClient, string serverPath, string userPath, bool isCopySubDirectories, bool isDeleteFilesFromOriginAfterTransfer);

    }
}
