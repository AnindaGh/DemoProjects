﻿using EncryptionLib;
using log4net;
using Renci.SshNet;
using Renci.SshNet.Sftp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileTransferSFTPLib.Helper
{
    /// <summary>
    /// Actions Related to File Transfer SFTP
    /// </summary>
    public class FileTransferSFTP : IFileTransferSFTP
    {

        protected ILog _Log;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="objLog">Log</param>
        public FileTransferSFTP(ILog objLog)
        {
            _Log = objLog;
        }

        /// <summary>
        /// Initializes a new instance of the SftpClient class.
        /// </summary>
        /// <param name="host">Host address</param>
        /// <param name="port">Port number</param>
        /// <param name="encryptedUsername">Encrypted Username</param>
        /// <param name="encryptedPassword">Encrypted Password</param>
        /// <returns></returns>
        public SftpClient GetSftpClient(string host, int port, string encryptedUsername, string encryptedPassword)
        {
            try
            {
                string username = Encryption.Decrypt(encryptedUsername);
                string password = Encryption.Decrypt(encryptedPassword);

                return new SftpClient(host, port, username, password);
            }
            catch (Exception ex)
            {
                _Log.ErrorFormat("GetSftpClient error : {0}", ex.ToString());
                throw;
            }
        }

        /// <summary>
        /// Download the files from user side to our server
        /// </summary>
        /// <param name="sftpClient">SftpClient Object</param>
        /// <param name="userPath">User path</param>
        /// <param name="serverPath">Our server Path</param>
        /// <param name="isCopySubDirectories">if true download the sub directories also</param>
        /// <param name="isDeleteFilesFromOriginAfterTransfer">If true delete from origin path after Transfer the file</param>
        public void DownloadDirectoryFiles(SftpClient sftpClient, string userPath, string serverPath, bool isCopySubDirectories, bool isDeleteFilesFromOriginAfterTransfer)
        {
            Directory.CreateDirectory(serverPath);
            IEnumerable<SftpFile> files = sftpClient.ListDirectory(userPath);
            _Log.InfoFormat("File Count in Input folder path is : {0}", files.Count());
            foreach (SftpFile file in files)
            {
                _Log.InfoFormat("File names : {0}", file.Name);
                if ((file.Name != ".") && (file.Name != ".."))
                {
                    string sourceFilePath = userPath + "/" + file.Name;
                    string destFilePath = Path.Combine(serverPath, file.Name);
                    if (file.IsDirectory)
                    {
                        if (isCopySubDirectories)
                        {
                            DownloadDirectoryFiles(sftpClient, sourceFilePath, destFilePath, isCopySubDirectories, isDeleteFilesFromOriginAfterTransfer);
                        }
                    }
                    else
                    {
                        using (Stream fileStream = File.Create(destFilePath))
                        {
                            sftpClient.DownloadFile(sourceFilePath, fileStream);
                            _Log.InfoFormat("The input file copied To : {0}, from : {1} ", destFilePath, sourceFilePath);
                        }

                        if (isDeleteFilesFromOriginAfterTransfer)
                        {
                            if (File.Exists(destFilePath))
                            {
                                sftpClient.DeleteFile(sourceFilePath);
                                _Log.InfoFormat("The input file Deleted from: {0}.", sourceFilePath);
                            }
                            else
                            {
                                _Log.InfoFormat("The input file not copied, which is unexpected. : {0}", sourceFilePath);
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Upload the files from our server to user side
        /// </summary>
        /// <param name="sftpClient">SftpClient Object</param>
        /// <param name="serverPath">Our server Path</param>
        /// <param name="userPath">User path</param>
        /// <param name="isCopySubDirectories">if true upload the sub directories also</param>
        /// <param name="isDeleteFilesFromOriginAfterTransfer">If true delete from origin path after Transfer the file</param>
        public void UploadDirectoryFiles(SftpClient sftpClient, string serverPath, string userPath, bool isCopySubDirectories, bool isDeleteFilesFromOriginAfterTransfer)
        {
            IEnumerable<FileSystemInfo> infos = new DirectoryInfo(serverPath).EnumerateFileSystemInfos();
            _Log.InfoFormat("Files/Folders Count in Output folder path is : {0}", infos.Count());
            foreach (FileSystemInfo info in infos)
            {
                _Log.InfoFormat("File/Folder name : {0}", info.Name);

                string serverFilePath = Path.Combine(serverPath, info.Name); // our server path 
                string userFilePath = Path.Combine(userPath, info.Name); // user server path

                if (info.Attributes.HasFlag(FileAttributes.Directory))
                {
                    if (isCopySubDirectories)
                    {
                        if (!sftpClient.Exists(userFilePath))
                        {
                            sftpClient.CreateDirectory(userFilePath);
                        }
                        UploadDirectoryFiles(sftpClient, serverFilePath, userFilePath, isCopySubDirectories, isDeleteFilesFromOriginAfterTransfer);
                    }
                }
                else
                {
                    using (Stream fileStream = new FileStream(serverFilePath, FileMode.Open))
                    {
                        sftpClient.BufferSize = 1024;
                        sftpClient.UploadFile(fileStream, userFilePath);
                        _Log.InfoFormat("The output file copied To : {0}, from : {1} ", userFilePath, serverFilePath);
                    }

                    if (isDeleteFilesFromOriginAfterTransfer)
                    {
                        if (sftpClient.Exists(userFilePath))
                        {
                            File.Delete(serverFilePath);
                            _Log.InfoFormat("Output file Deleted from: {0}.", serverFilePath);
                        }
                        else
                        {
                            _Log.InfoFormat("Output file not copied, which is unexpected. : {0}", serverFilePath);
                        }
                    }
                }
            }

            if (isDeleteFilesFromOriginAfterTransfer)
            {
                deleteEmptyDirectory(serverPath);
            }
        }

        /// <summary>
        /// Delete all empty Directories
        /// </summary>
        /// <param name="startLocation">Directory Path</param>
        private void deleteEmptyDirectory(string startLocation)
        {
            foreach (var directory in Directory.GetDirectories(startLocation))
            {
                deleteEmptyDirectory(directory);
                if (Directory.GetFiles(directory).Length == 0 && Directory.GetDirectories(directory).Length == 0)
                {
                    Directory.Delete(directory, false);
                    _Log.InfoFormat("Empty Folder Deleted : {0}", directory);
                }
            }
        }

    }
}
