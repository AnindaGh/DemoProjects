﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileTransferSFTPLib.DTO
{
    /// <summary>
    /// 
    /// </summary>
    public class FileTransferInfo
    {
        /// <summary>
        /// priorities of transfer order // priority 1 will start first then 2,3...
        /// </summary>
        public int TransferOrder { get; set; }

        /// <summary>
        /// TransferOption whether Upload ( from our server to SFTP user server ) or Download ( From SFTP Server to our server )
        /// </summary>
        public String TransferOption { get; set; }

        /// <summary>
        /// SFTP server path
        /// </summary>
        public String UserFolderPath { get; set; } 

        /// <summary>
        /// Our server local path
        /// </summary>
        public String ServerFolderPath { get; set; }

        /// <summary>
        /// If true transfer the sub directories also
        /// </summary>
        public bool IsCopySubirectories { get; set; }

        /// <summary>
        /// If true delete from orgin path after transfer the file
        /// </summary>
        public bool IsDeleteFilesFromOriginAfterTransfer { get; set; }

        /// <summary>
        /// Quick note related to Transfer file
        /// </summary>
        public string Note { get; set; }


    }
}
