﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileTransferSFTPLib.DTO
{
    public class FileTransferConfig
    {
        public String SFTP_HOST { get; set; }
        public String SFTP_PORT { get; set; }
        public String SFTP_ENCRYPTEDUSERNAME { get; set; }
        public String SFTP_ENCRYPTEDPASSWORD { get; set; }
        public String FILE_TRANSFER_INFO  { get; set; } 


    }
}
