﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObserverDemo
{
    public class WeatherStation : ISubject
    {
        private List<IObserver> observers;
        private float temperature;
        public float Temperature {
            get { return temperature; }
            set
            {
                temperature = value;
                Notify();
            }
        
        }

        public WeatherStation()
        {
            observers = new List<IObserver>();
        }

        public void Attach(IObserver observer)
        {
            observers.Add(observer);
        }

        public void Notify()
        {
            observers.ForEach(o =>
            {
                o.Update(this);
            });
        }
    }
}
