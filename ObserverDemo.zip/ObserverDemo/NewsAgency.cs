﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObserverDemo
{
    public class NewsAgency : IObserver
    {
        public String AgencyName { get; set; }

        public NewsAgency(String name)
        {
            AgencyName = name;
        }
        public void Update(ISubject subject)
        {
            if (subject is WeatherStation weatherStation)
            {
                Console.WriteLine(AgencyName + " Reporting Temp :" + weatherStation.Temperature);
            }
        }
    }
}
