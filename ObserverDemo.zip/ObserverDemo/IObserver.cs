﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObserverDemo
{
    public interface IObserver
    {
        void Update(ISubject subject);
    }
}
