﻿using System;

namespace ObserverDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            WeatherStation weatherStation = new WeatherStation();

            NewsAgency newsAgency1 = new NewsAgency("ABP");
            weatherStation.Attach(newsAgency1);

            NewsAgency newsAgency2 = new NewsAgency("NDTV");
            weatherStation.Attach(newsAgency2);

            weatherStation.Temperature = 31.2f;

            weatherStation.Temperature = 15.4f;

            weatherStation.Temperature = 10.2f;

            


        }
    }
}
