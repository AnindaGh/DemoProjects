﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObserverDemo
{
    public interface ISubject
    {
        public void Attach(IObserver observer);
        void Notify();
        
    }
}
