using System;

namespace SwaggerDemo
{
    public class WeatherForecast
    {
        /// <summary>
        /// Date for Weather
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Temparture in Celcius
        /// </summary>
        public int TemperatureC { get; set; }

        /// <summary>
        /// Temp in Fahreninheit
        /// </summary>
        public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);

        public string Summary { get; set; }
    }
}
