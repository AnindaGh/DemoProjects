﻿using BenchmarkDotNet.Running;
using System;

namespace BenchMarkDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            BenchmarkRunner.Run<DateParserBenchMarks>();
        }
    }
}
