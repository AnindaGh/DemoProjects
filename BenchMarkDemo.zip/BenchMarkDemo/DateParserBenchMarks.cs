﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Order;
using System;
using System.Collections.Generic;
using System.Text;

namespace BenchMarkDemo
{
    [MemoryDiagnoser]
    [Orderer(SummaryOrderPolicy.FastestToSlowest)]
    [RankColumn]
    public class DateParserBenchMarks
    {
        private const string DateTime = "2009-06-15T13:45:30 ";
        private static readonly DateParser Parser = new DateParser();

        [Benchmark(Baseline =true)]
        public void GetYearFromDateTime()
        {
            Parser.GetYearByParsing(DateTime);
        }

        [Benchmark]
        public void GetYearBySplit()
        {
            Parser.GetYearFromSplit(DateTime);
        }

        [Benchmark]
        public void GetYearBySubstring()
        {
            Parser.GetYearBySubString(DateTime);
        }
    }
}
