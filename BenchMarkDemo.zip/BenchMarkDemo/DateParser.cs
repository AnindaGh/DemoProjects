﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BenchMarkDemo
{
    public class DateParser
    {
        //2009-06-15T13:45:30 
        public int GetYearByParsing(string dateTime)
        {
           return DateTime.Parse(dateTime).Year;
        }

        public string GetYearBySubString(string dateTime)
        {
            var index = dateTime.IndexOf('-');
            return dateTime.Substring(0, index);
        }

        public int GetYearFromSplit(string dateTime)
        {
            var splitonHyphen = dateTime.Split('-');
            return int.Parse(splitonHyphen[0]);
        }
    }
}
