``` ini

BenchmarkDotNet=v0.13.1, OS=Windows 10.0.18363.1977 (1909/November2019Update/19H2)
Intel Core i5-6300U CPU 2.40GHz (Skylake), 1 CPU, 4 logical and 2 physical cores
.NET SDK=5.0.204
  [Host]     : .NET Core 3.1.16 (CoreCLR 4.700.21.26205, CoreFX 4.700.21.26205), X64 RyuJIT
  DefaultJob : .NET Core 3.1.16 (CoreCLR 4.700.21.26205, CoreFX 4.700.21.26205), X64 RyuJIT


```
|              Method |      Mean |    Error |    StdDev |    Median | Ratio | RatioSD | Rank |  Gen 0 | Allocated |
|-------------------- |----------:|---------:|----------:|----------:|------:|--------:|-----:|-------:|----------:|
|  GetYearBySubstring |  31.61 ns | 0.982 ns |  2.753 ns |  30.34 ns |  0.06 |    0.01 |    1 | 0.0204 |      32 B |
|      GetYearBySplit | 189.94 ns | 2.882 ns |  4.402 ns | 188.76 ns |  0.36 |    0.02 |    2 | 0.1018 |     160 B |
| GetYearFromDateTime | 530.66 ns | 8.900 ns | 21.664 ns | 522.85 ns |  1.00 |    0.00 |    3 |      - |         - |
