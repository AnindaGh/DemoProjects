﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace EraseJunkFiles
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Deleting old files!");
            IniFile ini = new IniFile(@"C:\EraseJunkFiles\Config.ini");
            //string directoryNam = ini.IniReadValue("A Section", "An Entry");
            string directoryName = ini.IniReadValue("DirectoryList", "path");

            String[] listofDirectories = directoryName.Split(';');


            foreach (string directory in listofDirectories)
            {

                string[] files = Directory.GetFiles(directory.Trim());

                foreach (string file in files)
                {

                    string originalFile = file.Trim();
                    FileInfo fi = new FileInfo(originalFile);


                    if (fi.CreationTime < DateTime.Now.AddDays(-120))
                    {
                        fi.Delete();

                    }

                }

                var emptyDirectories = Directory.GetDirectories(directory.Trim());

                foreach (var emptyDirectory in emptyDirectories)
                {
                    DirectoryInfo di = new DirectoryInfo(emptyDirectory);

                    if (di.GetFiles().Length == 0)
                    {
                        di.Delete();
                    }

                }

            }
        }
    }
}
