﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgorithmDemo
{
    public class NumberManipulation
    {
        //{1,2,2, 4, 6,7,7,7,8,12,12,12,13}
        public int[] removeDuplicates(int[] arr)
        {
            
            int[] dup = new int[arr.Length];
            for(int i = 0; i < arr.Length - 1; i++)
            {
                if(arr[i] != arr[i + 1])
                {
                    dup[i] = arr[i];
                }
                else if(arr[i] == arr[i + 1])
                {
                    dup[i] = arr[i + 1];
                }
            }

            return dup;
        }
    }
}
