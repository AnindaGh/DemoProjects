﻿using System;

namespace AlgorithmDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            //string duplicates = "ddjjkkrtuffl";
            //StringManipulation sm = new StringManipulation();
            //var distinctValues =  sm.removeDuplicates(duplicates);
            //Console.WriteLine(distinctValues);

            //string csglatin = "I am a Latin";
            //string latinOutput = sm.csgLatin(csglatin);  //Output : Ima amma ama Latinb
            //Console.WriteLine(latinOutput);

            //int[] arr = new int[] { 5, 7, 13, 34, 55, 67, 69, 89 };
            //Search searchobj = new Search();
            //int position = searchobj.binarySearch(arr, 13);

            //int[] duparr = new int[] { 1, 2, 2, 4, 6, 7, 7, 7, 8, 12, 12, 12, 13 };
            //NumberManipulation numobj = new NumberManipulation();
            //var result =  numobj.removeDuplicates(duparr);
            //foreach(var value in result)
            //{
            //    Console.WriteLine(value);
            //}


            Employee emp = new Employee();
            Console.WriteLine(emp.getData());

            Employee ce = new ContractEmployee();
            Console.WriteLine(ce.getData());
          

            GenericClasses<int> mlist = new GenericClasses<int>();
            mlist.Add(6);


        }
    }
}
