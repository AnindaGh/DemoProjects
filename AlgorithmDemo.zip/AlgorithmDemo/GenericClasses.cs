﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgorithmDemo
{
    public class GenericClasses<T>
    {
        public void Add(T value)
        {
            
        }
    }
}
