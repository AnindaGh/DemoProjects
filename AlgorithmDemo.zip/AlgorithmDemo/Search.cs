﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgorithmDemo
{
    public class Search
    {
        public int binarySearch(int[] arr,int searchval)
        {
            int mid = arr.Length / 2;
            int position = 0;
            if(searchval < arr[mid])
            {
                for(int i = 0; i < arr[mid]; i++)
                {
                    if(arr[i] == searchval)
                    {
                        position = i + 1;
                        break;
                    }
                }
            }
            if(searchval > arr[mid])
            {
                for(int j=arr[mid]; j< arr.Length; j++)
                {
                    if(arr[j] == searchval)
                    {
                        position = j + 1;
                        break;
                    }
                }
            }
            if(searchval == arr[mid])
            {
                position = mid + 1;
            }

            return position;
        }
    }
}
