﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AlgorithmDemo
{
    public class StringManipulation
    {
        public string removeDuplicates(string input)
        {
            //   d d j j k k r t u f f l
            char[] original = input.ToCharArray();
            char[] dup = new char[original.Length];

            for(int i = 0; i < original.Length -1; i++)
            {
                if(original[i] == original[i + 1])
                {
                    original[i] = ' ';
                }
            }
            String str = new String(original);
            str = str.Replace(" ", String.Empty);
            return str;
        }

        public bool identifyVowels(char input)
        {
            char[] vowel = new char[] { 'a', 'e', 'i', 'o', 'u' };
            bool flag = false;
            for(int i=0; i<vowel.Length; i++)
            {
                if(vowel[i] == input)
                {
                    flag = true;
                    break;
                }
            }
            return flag;
        }

        // I am a Latin
        public string csgLatin(string input)
        {
            string[] splitArray = input.Split();

            for(int i = 0; i < splitArray.Length; i++)
            {
                
                char firstChar = char.Parse(splitArray[i].Substring(0, 1).ToLower());

                if (identifyVowels(firstChar))
                {
                    StringBuilder sbvowel = new StringBuilder(splitArray[i]);
                    sbvowel.Append("ma");
                    splitArray[i] = sbvowel.ToString();
                }
                else
                {
                    StringBuilder sbconsonant = new StringBuilder(splitArray[i]);
                    sbconsonant.Append("b");
                    splitArray[i] = sbconsonant.ToString();

                }
            }
            string convertedString =  string.Join(" ", splitArray);
            return convertedString;
        }
    }
}
