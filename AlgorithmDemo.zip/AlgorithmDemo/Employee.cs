﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgorithmDemo
{
    public class Employee
    {
        public int da = 3;

        public virtual int getData()
        {
            return 3;
        }
    }

    public class ContractEmployee : Employee
    {
        public override int getData()
        {
            return 5;
        }

    }
}
