﻿using EmployeeRecordManagement.DBModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using FromBodyAttribute = Microsoft.AspNetCore.Mvc.FromBodyAttribute;
using HttpPostAttribute = System.Web.Http.HttpPostAttribute;

namespace EmployeeRecordManagement.Controllers
{
    public class EmployeeController : ControllerBase
    {
        public static EmployeeManagementContext DBContext;
        public EmployeeController(EmployeeManagementContext dbContext)
        {
            DBContext = dbContext;
        }
      
        [HttpPost]
        public ActionResult AddComments([FromBody]string comment,[FromBody]int employeedId)
        {
            using (DBContext)
            {
                var commentData = DBContext.Set<CommentDatum>();
                commentData.Add(new CommentDatum {CommentContent = comment,CommentDate=DateTime.Now.ToString(),EmployeeId = employeedId });

            }
            return Ok();
        }
    }
}
