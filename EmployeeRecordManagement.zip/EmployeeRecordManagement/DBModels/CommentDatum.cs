﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EmployeeRecordManagement.DBModels
{
    public partial class CommentDatum
    {
        public int CommentId { get; set; }
        public string CommentDate { get; set; }
        public string CommentContent { get; set; }
        public int? EmployeeId { get; set; }
    }
}
