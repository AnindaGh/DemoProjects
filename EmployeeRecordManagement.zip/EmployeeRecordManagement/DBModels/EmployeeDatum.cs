﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EmployeeRecordManagement.DBModels
{
    public partial class EmployeeDatum
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; }
        public string JobTitle { get; set; }
        public double? Salary { get; set; }
        public string Department { get; set; }
        public string Manager { get; set; }
        public string Address { get; set; }
        public string Doj { get; set; }
    }
}
