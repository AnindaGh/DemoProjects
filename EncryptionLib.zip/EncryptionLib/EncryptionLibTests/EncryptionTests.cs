﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EncryptionLib;
using NUnit.Framework;

namespace EncryptionLib.Tests
{
    public class EncryptionTests
    {
        [Test]
        public void EncryptTest()
        {
            string password = "Mercedes222@@";
            var output = Encryption.Encrypt(password);

            Assert.IsTrue(output.Length != 0);
        }

        [Test]
        public void DecryptTest()
        {
            string password = "Mercedes222@@";
            var output = Encryption.Encrypt(password);
            string result = Encryption.Decrypt(output);

            Assert.IsTrue(result.Length != 0);
        }
    }
}