﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EncryptionLib;

namespace Encrypt
{
    class Program
    {
        static void Main(string[] args)
        {
            EncryptMain objMain = new EncryptMain();
            objMain.EncryptText();

            //objMain.DecryptText();
        }
    }

    class EncryptMain
    {

        public void EncryptText()
        {
            //string password = "server=C152T0063464289;database=Verify_DB;uid=sa;password=Dg0btb1224+9;";
            string password = "Daimlerkorea@123";
            //string password = "Korea@123";
            //string password = "Winter02!!";
            var output = Encryption.Encrypt(password);
            Console.WriteLine(output);
 
            Console.ReadLine();
        }

        public void DecryptText()
        {
            //String output = "lpDvkEwkQBjfu50Us0IVoV26un42j0KEZWWmE+30fDg=";
            String output = "60juXui98bW3esjysTBXmow5iTwGRRmmXOOv+nN+XMI=";

            var result = Encryption.Decrypt(output);
            Console.WriteLine(result);

            Console.ReadLine();
        }

    }

}
