﻿using MailKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCREmailInputLib
{
    public interface IEmailService
    {
        void TestIMAP(int configID);
        void TestSMTP(int configID, string recipientEmail);
        void SendEmail(String strEmailHost, String strFromEmail, List<String> objToEmailList, String strSubj, String strMessage);
        void Extract_IMAP_Email(int emailConfigId, bool overwriteFile);
        OCREmailTransaction DownloadEmailAttachment(OCREmailConfiguration config, IMessageSummary item, IMailFolder objMailFolder, bool overwrite);
        int SaveEmailToDB(IMessageSummary item, OCREmailConfiguration config, OCREmailTransaction email);
        void DeleteEmail(List<UniqueId> uids, string folderName);
        void MoveEmail(IMessageSummary email, IMailFolder objMailFolder, string imapDestFolderName);


    }
}
