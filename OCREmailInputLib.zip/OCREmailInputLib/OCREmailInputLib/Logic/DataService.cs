﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCREmailInputLib
{
    public class DataService
    {
        public List<OCREmailConfiguration> FilterEmailInfoByCountry(List<OCREmailConfiguration> data, string CountryCode)
        {

            if(data.Count != 0)
            {
                List<OCREmailConfiguration> results = data.Where(a => a.MarketName == CountryCode && a.Status == "A").ToList();
                return results;
            }
            else
            {
                return null;
            }
            
        }
    }
}
