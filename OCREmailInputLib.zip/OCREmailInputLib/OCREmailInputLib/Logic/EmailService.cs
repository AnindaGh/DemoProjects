﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using MailKit;
using MailKit.Net.Imap;
using MimeKit;
using MailKit.Search;
using log4net;
using System.Net.Mail;
using System.Configuration;

namespace OCREmailInputLib
{
    /// <summary>
    /// Contains email methods
    /// </summary>
    public class EmailService : IEmailService 
    { 
        protected ILog _log;
        protected ImapClient _ImapClient;
        protected DataAccess.DBAccess _DBAccess;
        protected string _connString;

        /// <summary>
        /// Constructor
        /// (1) instantiate instance variables
        /// (2) decrypt connection string
        /// (3) set instance variable value
        /// </summary>
        public EmailService()
        {
            _log = LogManager.GetLogger("DefaultLog");

            _ImapClient = new ImapClient();
             
            _connString = ConfigurationManager.ConnectionStrings["ABBYY_DB"].ConnectionString;

            _DBAccess = new DataAccess.DBAccess(_connString, _log);
        }

        /// <summary>
        /// This method is to test for IMAP port connectivity issue
        /// It will authenticate using Email credentials and get TOTAL inbox mails
        /// </summary>
        /// <param name="configID">Email Configuration ID</param>
        public void TestIMAP(int configID)
        {
            try
            {  
                // grab email config from DB 
                OCREmailConfiguration config = _DBAccess.GetEmailDetailsById(configID);

                _ImapClient.Connect(config.EmailServer, config.Port, true);
                _ImapClient.Authenticate(config.Username, config.Password);
                _ImapClient.Inbox.Open(FolderAccess.ReadOnly);

                //search for all emails in Inbox
                var totalIds = _ImapClient.Inbox.Search(SearchQuery.All);
                var unreadIds = _ImapClient.Inbox.Search(SearchQuery.NotSeen);

                _log.InfoFormat("Total INBOX emails: {0}", totalIds.Count);
                _log.InfoFormat("Total unread emails: {0}", unreadIds.Count);

            }
            catch (Exception ex)
            {
                _log.ErrorFormat("An error occurred {0}", ex.StackTrace);
            }

        }

        /// <summary>
        /// This method is to test for SMTP port connectivity issue
        /// It will send a test email to provided email address
        /// </summary>
        /// <param name="configID">Email Configuration ID</param>
        /// <param name="recipientEmail">Email Address to receive test email</param>
        public void TestSMTP(int configID, string recipientEmail)
        {
            try
            {  
                // grab email config from DB 
                OCREmailConfiguration config = _DBAccess.GetEmailDetailsById(configID);

                List<string> emailList = new List<string>();
                emailList.Add(recipientEmail);
                SendEmail(config.EmailServer, "ocr-no-reply@daimler.com", emailList, "Testing Email", "Sending Email From " + System.Environment.MachineName);
            }
            catch (Exception ex)
            {
                _log.ErrorFormat("An error occurred {0}", ex.StackTrace);
            }
        }

        /// <summary>
        /// Send email using SMTP
        /// </summary>
        /// <param name="strEmailHost">SMTP Host server</param>
        /// <param name="strFromEmail">Sender email address</param>
        /// <param name="objToEmailList">Recipient email address</param>
        /// <param name="strSubj">Email subject</param>
        /// <param name="strMessage">Email message</param>    
        public void SendEmail(String strEmailHost, String strFromEmail, List<String> objToEmailList, String strSubj, String strMessage)
        {
            SmtpClient objSmtp = new SmtpClient(strEmailHost);
            MailMessage mail = new MailMessage();
            mail.From = new MailAddress(strFromEmail);
            mail.IsBodyHtml = true;
            // mail.To.Add(new MailAddress(strToEmail));
            foreach (String strEmail in objToEmailList)
            {
                mail.To.Add(new MailAddress(strEmail));
            }
            mail.Subject = strSubj;
            mail.Body = strMessage;
            objSmtp.Send(mail);
        }
        
        /// <summary>
        /// (1) Get email server details from [OCREmailConfiguration] table
        /// (2) Authenticate
        /// (3) Read folder
        /// (4) Download attachment to specified folder
        /// (5) Move to respective folders (whether successful or not
        /// (6) Save email transaaction to [OCREmailTransaction]
        /// </summary>
        /// <param name="emailConfigId">Email configuration id</param>
        public void Extract_IMAP_Email(int emailConfigId, bool overwriteFile)
        {  
            OCREmailConfiguration config = _DBAccess.GetEmailDetailsById(emailConfigId);
            
            if (config == null || config.Protocol != "IMAP")
            { 
                _log.WarnFormat("[Extract_IMAP_Email] [NO EMAIL CONFIGURATIONS FOUND IN DATABASE] for configID : {0}", emailConfigId);
                return;
            }
            else if (config.Protocol == "IMAP")
            {
                try
                {  
                    // open mailbox using Email Config credentials
                    _ImapClient.Connect(config.EmailServer, config.Port, true);
                    _ImapClient.Authenticate(config.Username, config.Password); 

                    // determine the correct EMAIL FOLDER
                    string emailReadFolder = config.ImapReadFolder;
                    var objMailFolder = _ImapClient.Inbox;
                    if (!String.IsNullOrEmpty(emailReadFolder))
                    {
                        objMailFolder = _ImapClient.GetFolder(emailReadFolder);
                    }

                    // open for Read/Write
                    objMailFolder.Open(FolderAccess.ReadWrite);

                    // grab all email IDs
                    var uids = objMailFolder.Search(SearchQuery.All);

                    if (uids.Any())
                    {

                        // fetch summary information for the search results (we will want the UID and the BODYSTRUCTURE
                        // of each message so that we can extract the text body and the attachments)
                        var items = objMailFolder.Fetch(uids, MessageSummaryItems.UniqueId | MessageSummaryItems.BodyStructure | MessageSummaryItems.Full).ToList();

                        List<OCREmailTransaction> emailTrans = new List<OCREmailTransaction>();

                        foreach (var item in items)
                        {
                            // new email object
                            OCREmailTransaction email = new OCREmailTransaction();

                            // grab attachment
                            email = DownloadEmailAttachment(config, item, objMailFolder, overwriteFile);

                            // move to respective FOLDERS
                            if (email.ExtractStatus.Equals("Extracted"))
                                MoveEmail(item, objMailFolder, config.ImapProcessedFolder);
                            else
                                MoveEmail(item, objMailFolder, config.ImapErrorFolder);

                            // save email record 
                            int txnId = SaveEmailToDB(item, config, email);
                        }
                    }
                    else
                    {
                        _log.Info("[Extract_IMAP_Email] [NO NEW EMAILS]");
                    }
                    _ImapClient.Disconnect(true);
                }
                catch (Exception ex)
                {
                    _log.ErrorFormat("Extract_IMAP_Email : {0}", ex);
                }
            } 
        }

        /// <summary>
        /// (1) Read email attachment
        /// (2) Download PDF attachment to specified folder 
        /// </summary>
        /// <param name="config">Email configuration Id</param>
        /// <param name="item">Email message item</param>
        /// <param name="objMailFolder">Email folder</param>
        /// <param name="overwrite">boolean flag to indicate if File overwrite will be implemented.Default value true</param>
        /// <returns></returns>
        public OCREmailTransaction DownloadEmailAttachment(OCREmailConfiguration config, IMessageSummary item, IMailFolder objMailFolder, bool overwrite)
        {
            // instantiate return object
            OCREmailTransaction email = new OCREmailTransaction();

            // vars
            string emailSubject = item.NormalizedSubject;
            string downloadPath = config.DownloadFilePath;

            // open MAILBOX
            objMailFolder.Open(FolderAccess.ReadWrite);

            try
            {
                if (item.Attachments.Any())
                {
                    // now iterate over all of the attachments and save them to disk
                    foreach (var attachment in item.Attachments)
                    {
                        // download the attachment just like we did with the body
                        var entity = objMailFolder.GetBodyPart(item.UniqueId, attachment);

                        // attachments can be either message/rfc822 parts or regular MIME parts
                        if (entity is MessagePart rfc822)
                        {
                            var path = Path.Combine(downloadPath, attachment.PartSpecifier + ".eml"); 
                            rfc822.Message.WriteTo(path);
                        }
                        else
                        {
                            var part = (MimePart)entity;

                            // note: it's possible for this to be null, but most will specify a filename
                            var fileName = part.FileName; 

                            if (fileName.ToLower().Contains("pdf"))
                            {
                                try
                                {
                                    var path = Path.Combine(downloadPath, fileName);

                                    // check boolean flag for overwrite
                                    // check if file exists, then append timestamp to filename
                                    if (File.Exists(path) && !overwrite)
                                    { 
                                        String strToAppend = DateTime.Now.AddMinutes(55).ToString("-dd''MM''yyyy-HHmmss");
                                        fileName = String.Format("{0}###{1}", strToAppend, fileName);
                                        path = Path.Combine(downloadPath, fileName);
                                    }
                                    
                                    // decode and save the content to a file
                                    using (var stream = File.Create(path))
                                        part.Content.DecodeTo(stream);

                                    email.AttachmentName = fileName;
                                    email.CreatedDate = System.DateTime.Now;
                                    email.ExtractStatus = "Extracted"; 

                                    _log.Info("[ATTACHMENT EXTRACTED]");
                                }
                                catch (Exception ex)
                                {
                                    _log.ErrorFormat("[FAILED TO EXTRACT] Email: {0} [ERROR] {1}", emailSubject, ex);
                                }
                            }
                            else
                            {

                                email.AttachmentName = fileName;
                                email.CreatedDate = System.DateTime.Now;
                                email.ExtractStatus = "Not Extracted"; 
                                
                                _log.WarnFormat("[ATTACHMENT NOT PDF] Email: {0}", emailSubject); 
                            } 
                        }
                    }
                }
                else
                {
                    email.AttachmentName = "";
                    email.CreatedDate = DateTime.Now;
                    email.ExtractStatus = "No Attachment";
                    
                    _log.WarnFormat("[NO ATTACHMENT] Email: {0}", emailSubject); 
                }
            }
            catch (Exception ex)
            {
                _log.ErrorFormat("[DownloadEmailAttachment] : {0}", ex);
            }

            // return object
            return email; 
        }

        /// <summary>
        /// Save email transaction to DB table [OCREmailTransaction]
        /// </summary>
        /// <param name="item">Email message item</param>
        /// <param name="config">Email configuration Id</param>
        /// <param name="email">Email object containing attachment details</param>
        /// <returns></returns>
        public int SaveEmailToDB(IMessageSummary item, OCREmailConfiguration config, OCREmailTransaction email)
        {
            _log.InfoFormat("[READING] Email: {0}", item.NormalizedSubject);

            DateTimeOffset? date = item.Envelope.Date;
            DateTime receivedDate = date.Value.DateTime;
            var from = item.Envelope.From;
            var subject = item.NormalizedSubject;

            email.EmailConfigurationId = config.EmailConfigurationId;
            email.MarketName = config.MarketName;
            email.EmailSubject = subject;
            email.EmailFrom = from.ToString();
            email.EmailReceivedTime = receivedDate;

            // Save!
            int emailTransactionId = _DBAccess.NewEmailTrans(email);

            return emailTransactionId;
        }

        /// <summary>
        /// Delete email from specified email folder
        /// </summary>
        /// <param name="uids">Email message id</param>
        /// <param name="folderName">Email folder</param>
        public void DeleteEmail(List<UniqueId> uids, string folderName)
        {
            var targetFolder = _ImapClient.GetFolder(folderName);
            targetFolder.Open(FolderAccess.ReadWrite);
            targetFolder.AddFlags(uids, MessageFlags.Deleted, true);
            targetFolder.Expunge(uids);
            _log.Info("[EMAILS DELETED]");
            targetFolder.Close();
        }

        /// <summary>
        /// Move email to a specified folder
        /// </summary>
        /// <param name="email">Email message item</param>
        /// <param name="objMailFolder">Email folder to read</param>
        /// <param name="imapDestFolderName">Email folder to move to</param>
        public void MoveEmail (IMessageSummary email, IMailFolder objMailFolder, string imapDestFolderName)
        {
            // get uniqueID of email to MOVE
            List<UniqueId> emailIDToMove = new List<UniqueId>();
            emailIDToMove.Add(email.UniqueId);

            // OPEN MAILBOX
            objMailFolder.Open(FolderAccess.ReadWrite);
             
            var query = SearchQuery.Uids(emailIDToMove);
            var uids = objMailFolder.Search(query);

            foreach (var uid in uids)
            {

                var matchFolder = _ImapClient.GetFolder(imapDestFolderName);
                if (matchFolder != null)
                {
                    try
                    {
                        objMailFolder.MoveTo(uid, matchFolder);
                    }
                    catch (Exception ex)
                    {
                        _log.ErrorFormat("[FAILED TO MOVE EMAIL] Email: {0} [ERROR]: {1}", email.NormalizedSubject, ex);
                    }
                } 
            } 
        }
        
    }
}
