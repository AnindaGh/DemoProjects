﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCREmailInputLib
{
    /// <summary>
    /// object containing Email configuration details
    /// referenced from [OCREmailConfiguration] table
    /// </summary>
    public class OCREmailConfiguration
    {
        public int EmailConfigurationId { get; set; }
        public string MarketName { get; set; }
        public string EmailServer { get; set; }
        public int Port { get; set; }
        public string Protocol { get; set; }
        public string Environment { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Status { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdateDate { get; set; }
        public string ImapReadFolder { get; set; }
        public string ImapProcessedFolder { get; set; }
        public string ImapErrorFolder { get; set; }
        public string DownloadFilePath { get; set; } 
    }
}
