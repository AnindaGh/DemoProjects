﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCREmailInputLib
{
    /// <summary>
    /// object containing Email transaction details
    /// referenced from [OCREmailTransaction] table
    /// </summary>
    public class OCREmailTransaction
    {
        public int EmailTransactionId { get; set; }
        public string MarketName { get; set; }
        public int EmailConfigurationId { get; set; }
        public string EmailFrom { get; set; }
        public string EmailSubject { get; set; }
        public DateTime EmailReceivedTime { get; set; }
        public string AttachmentName { get; set; }
        public string ExtractStatus { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
