﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OCREmailInputLib;
using log4net;

namespace OCREmailInputLibTester
{
    class Program
    { 
        static void Main(string[] args)
        {   

            log4net.Config.XmlConfigurator.ConfigureAndWatch(new System.IO.FileInfo(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile));
            ILog objLog = LogManager.GetLogger("DefaultLog"); 

            EmailService emailSrv = new EmailService();
            int emailConfig = 6;
            emailSrv.Extract_IMAP_Email(emailConfig);

            Console.ReadLine();
        }

        private static void GetDecryptedPassword()
        {
            //ILog _log = LogManager.GetLogger("RollingFileAppender");
            //string connString = ConfigurationManager.ConnectionStrings["ABBYY_UAT_DB"].ConnectionString; 

            //// DECRYPT Password
            //DBConnection dbConn = new DBConnection();

            //var list = dbConn.GetEmailMasterData(connString, _log);

            //foreach (OCREmailConfiguration oe in list)
            //{
            //    Console.WriteLine(oe.Password);
            //    Console.ReadLine();
            //}
        }

        private static void TestIMAPConnection()
        {
            Console.WriteLine("TESTING IMAP CONNECTION...");

            ILog _log = LogManager.GetLogger("RollingFileAppender");
            string connString = ConfigurationManager.ConnectionStrings["ABBYY_UAT_DB"].ConnectionString;
            int configID = Convert.ToInt16(ConfigurationManager.AppSettings["EMAIL_IMAP_ID"]);

            EmailService emailSrv = new EmailService();
            emailSrv.TestIMAP(configID);

            Console.WriteLine("DONE"); 
        }

        private static void TestSMTPSending()
        {
            Console.WriteLine("TESTING SMTP SENDING EMAIL...");

            ILog _log = LogManager.GetLogger("RollingFileAppender");
            string connString = ConfigurationManager.ConnectionStrings["ABBYY_UAT_DB"].ConnectionString;
            int configID = Convert.ToInt16(ConfigurationManager.AppSettings["EMAIL_SMTP_ID"]);
            string email = "test@email.com";

            EmailService emailSrv = new EmailService();
            emailSrv.TestSMTP(configID, email);

            Console.WriteLine("DONE");
        }
    }
}
