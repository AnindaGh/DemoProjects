﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using NUnit.Framework;
using OCREmailInputLib;

namespace OCREmailInputLibTests.Logic
{
    class DataServiceTest
    {
        [Test]
        public void FilterEmailInfoByCountryTest()
        {
            ILog _log = LogManager.GetLogger("RollingFileAppender");
            string connString = @"Data Source=C830LX059397345\SQLEXPRESS;Initial Catalog=OCRTest;Integrated Security=True";

            List<OCREmailConfiguration> emailConfigurations = new List<OCREmailConfiguration>();
            DBConnection dBConnection = new DBConnection();
            emailConfigurations = dBConnection.GetEmailMasterData(connString, _log);
            DataService dataService = new DataService();
            emailConfigurations = dataService.FilterEmailInfoByCountry(emailConfigurations, "AU");
            Assert.IsNotNull(emailConfigurations);
        }
    }
}
