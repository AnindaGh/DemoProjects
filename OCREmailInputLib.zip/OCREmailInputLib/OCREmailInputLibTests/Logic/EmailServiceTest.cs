﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using MailKit;
using MailKit.Net.Imap;
using Moq;
using NUnit.Framework;
using OCREmailInputLib;

namespace OCREmailInputLibTests.Logic
{
    class EmailServiceTest
    {
        protected IEmailService mockEmail;
        protected IMailFolder mockMailFolder;

        [SetUp]
        public void Setup()
        {
            // create some mock data 
            List<UniqueId> uniqueIds = new List<UniqueId>();
            uniqueIds.Add(new UniqueId()); 

            IMessageSummary messageSummary = null;

            string folderToDelete = "Trash";

            string folderToMove = "Processed";

            int emailConfigId = 1;

            string strEmailHost = "smtpserver";
            string strFromEmail = "no-reply@daimler.com";
            List<string> objToEmailList = new List<string>();
            objToEmailList.Add("emailMe@email.com");
            string strSubj = "test email";
            string strMessage = "this is a test email";

            OCREmailConfiguration ocrEmailConfigData = new OCREmailConfiguration
            {
                EmailConfigurationId = 1
            };
            List<OCREmailConfiguration> oCREmailConfigList = new List<OCREmailConfiguration>();
            oCREmailConfigList.Add(ocrEmailConfigData);
            OCREmailTransaction txnData = new OCREmailTransaction
            {
                EmailFrom = "from@email.com",
                EmailSubject = "emailSubject",
                EmailConfigurationId = 1,
                EmailTransactionId = 101
            };
            // --END mock data 

            // Mock the DBAccess object using Moq
            Mock<IEmailService> mockEmailService = new Mock<IEmailService>(); 

            // setup  
            mockEmailService.Setup(e => e.DeleteEmail(uniqueIds, folderToDelete));
            mockEmailService.Setup(e => e.DownloadEmailAttachment(ocrEmailConfigData, null, null)).Returns(txnData);
            mockEmailService.Setup(e => e.Extract_IMAP_Email(emailConfigId));
            mockEmailService.Setup(e => e.SaveEmailToDB(messageSummary, ocrEmailConfigData, txnData)).Returns(0);
            mockEmailService.Setup(e => e.MoveEmail(null, null, folderToMove));
            mockEmailService.Setup(e => e.SendEmail(strEmailHost, strFromEmail, objToEmailList, strSubj, strMessage));
            mockEmailService.Setup(e => e.TestIMAP(emailConfigId));
            mockEmailService.Setup(e => e.TestSMTP(emailConfigId, strFromEmail));

            // --END setup

            // Complete the setup of mock dbaccess object
            mockEmail = mockEmailService.Object;
        }

        [Test]
        public void Download_Test()
        {
            OCREmailConfiguration ocrEmailConfigData = new OCREmailConfiguration
            {
                EmailConfigurationId = 1
            };
            IMailFolder emailFolder = null;
            IMessageSummary messageSummary = null;
            var result = mockEmail.DownloadEmailAttachment(ocrEmailConfigData, messageSummary, emailFolder);
            Assert.IsTrue(result == null);
        }

        [Test]
        public void Save_Test()
        {
            OCREmailConfiguration ocrEmailConfigData = new OCREmailConfiguration
            {
                EmailConfigurationId = 1
            }; 
            IMessageSummary messageSummary = null;
            OCREmailTransaction txnData = new OCREmailTransaction
            {
                EmailFrom = "from@email.com",
                EmailSubject = "emailSubject",
                EmailConfigurationId = 1,
                EmailTransactionId = 101
            };
            var result = mockEmail.SaveEmailToDB(messageSummary, ocrEmailConfigData, txnData);
            Assert.IsTrue(result==0);
        }

    }
}
