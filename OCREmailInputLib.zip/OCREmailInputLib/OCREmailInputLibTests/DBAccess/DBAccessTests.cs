﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OCREmailInputLib.DataAccess;
using NUnit.Framework;
using Moq;

namespace OCREmailInputLib.Tests
{
    public class DBAccessTests
    {
        protected IDBAccess mockRepo;

        [SetUp]
        public void Setup()
        {
            // create some mock data 
            int configId = 1;
            OCREmailConfiguration ocrEmailConfigData = new OCREmailConfiguration
            {
                EmailConfigurationId = 1 
            };
            List<OCREmailConfiguration> oCREmailConfigList = new List<OCREmailConfiguration>();
            oCREmailConfigList.Add(ocrEmailConfigData);
            OCREmailTransaction txnData = new OCREmailTransaction {
                EmailFrom="from@email.com", 
                EmailSubject="emailSubject",
                EmailConfigurationId=1
            } ;

            // --END mock data 

            // Mock the DBAccess object using Moq
            Mock<IDBAccess> mockDBAccess = new Mock<IDBAccess>();

            // setup 
            mockDBAccess.Setup(db => db.GetEmailDetailsById(configId)).Returns(ocrEmailConfigData);

            mockDBAccess.Setup(db => db.GetEmailMasterData()).Returns(oCREmailConfigList);

            mockDBAccess.Setup(db => db.NewEmailTrans(txnData)).Returns(101);
            // --END setup

            // Complete the setup of mock dbaccess object
            mockRepo = mockDBAccess.Object;
        }
         
        [TestCase("0")]
        public void GetEmailDetailsById_InvalidTest(int id)
        {
            var email = mockRepo.GetEmailDetailsById(id);
            Assert.IsTrue(email== null);
        }

        [TestCase("1")]
        public void GetEmailDetailsById_ValidTest(int id)
        {
            var email = mockRepo.GetEmailDetailsById(id);
            Assert.IsTrue(email.EmailConfigurationId == 1);
        }

        public void GetEmailMasterData_Test()
        {
            var emailList = mockRepo.GetEmailMasterData();
            Assert.IsTrue(emailList.Count > 0);
        }

        public void NewEmailTrans_Test()
        {
            OCREmailTransaction o = new OCREmailTransaction
            {
                EmailConfigurationId=1,
                EmailTransactionId=101
            };
            var txnId = mockRepo.NewEmailTrans(o);
            Assert.IsTrue(txnId == 101);
        }
    }
}
