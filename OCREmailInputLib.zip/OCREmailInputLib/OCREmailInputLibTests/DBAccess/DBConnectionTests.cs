﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OCREmailInputLib;
using NUnit.Framework;

namespace OCREmailInputLib.Tests
{
    public class DBConnectionTests
    {
        [Test]
        public void GetEmailMasterDataTest()
        {
            DBConnection dbConn = new DBConnection();
            string connString = @"Server=C830LX057503983\SQLEXPRESS;Database=Flexi12UAT;User Id=abbyyuser;Password=pass1234;";
            var data = dbConn.GetEmailMasterData(connString, null);
            Assert.IsNotNull(data);
        }
    }
}